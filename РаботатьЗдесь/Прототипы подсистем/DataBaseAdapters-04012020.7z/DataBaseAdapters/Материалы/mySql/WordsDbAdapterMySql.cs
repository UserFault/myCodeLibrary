﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data.Common;


namespace WordsMySqlLib
{
    public class WordsDbAdapterMySql
    {

        //TODO: добавить создание и удаление таблицы составных словоформ, после того как она будет разработана и описана в вики.

        /// <summary>
        /// Database connection
        /// </summary>
        private MySqlConnection m_connection;
        ///// <summary>
        ///// Database transaction
        ///// </summary>
        //private MySqlTransaction m_transaction;
        /// <summary>
        /// InsertLexemToTableWord() command
        /// </summary>
        private MySqlCommand m_InsertToLexemCmd1;
        /// <summary>
        /// UpdateLexem command
        /// </summary>
        private MySqlCommand m_UpdateLexemCmd;
        /// <summary>
        /// UpdateLink command
        /// </summary>
        private MySqlCommand m_UpdateLinkCmd;
        /// <summary>
        /// InsertLink command
        /// </summary>
        private MySqlCommand m_InsertToLinkCmd;
        /// <summary>
        /// UpdateLink command
        /// </summary>
        private MySqlCommand m_UpdateFreqCmd;
        /// <summary>
        /// InsertLink command
        /// </summary>
        private MySqlCommand m_InsertToFreqCmd;
        /// <summary>
        /// FreqGet command
        /// </summary>
        private MySqlCommand m_FreqGetCmd;
        ///// <summary>
        ///// CountLexemInTableWord() command
        ///// </summary>
        //private MySqlCommand m_CountWordCmd1;


        /// <summary>
        /// Конструктор
        /// </summary>
        public WordsDbAdapterMySql()
        {
            m_connection = new MySqlConnection();
            //init commands
            m_InsertToLexemCmd1 = null;
            m_InsertToLinkCmd = null;
            m_UpdateLexemCmd = null;            
            m_UpdateLinkCmd = null;
            m_FreqGetCmd = null;
            //m_CountWordCmd1 = null;
        }
        #region *** Общие функции ***
        /// <summary>
        /// NT-Подключиться к БД 
        /// </summary>
        /// <param name="connectionString">Строка подключения</param>
        public void Connect(string connectionString)
        {
            //create connection
            m_connection.ConnectionString = connectionString;

            //open connection
            m_connection.Open();

            return;
        }
        /// <summary>
        /// NT-Отключиться от БД
        /// </summary>
        public void Disconnect()
        {
            //if connection is open, close it
            if (m_connection.State == System.Data.ConnectionState.Open)
                m_connection.Close();
            //reset commands
            m_InsertToLexemCmd1 = null;
            m_InsertToLinkCmd = null;
            m_UpdateLexemCmd = null;
            m_UpdateLinkCmd = null;
            m_FreqGetCmd = null;

            return;
        }
        /// <summary>
        /// NT-начать транзакцию - это должно сильно ускорить массовые операции записи.
        /// После завершения операции транзакцию необходимо подтвердить или отменить.
        /// </summary>
        /// <returns>Объект транзакции.</returns>
        /// <remarks>
        /// Это выносит объект транзакции в вызывающий код, что требует подключения пространства имен MySql.
        /// Хотелось бы избежать этого подключения, чтобы в приложении полностью абстрагироваться от БД.
        /// </remarks>
        public DbTransaction НачатьТранзакцию()
        {
            return m_connection.BeginTransaction();
        }
        /// <summary>
        /// Отменить транзакцию, отменить все сделанные изменения 
        /// </summary>
        /// <param name="tran"></param>
        public void ОткатитьТранзакцию(DbTransaction tran)
        {
            tran.Rollback();
        }
        /// <summary>
        /// Подтвердить транзакцию и все внесенные изменения
        /// </summary>
        /// <param name="tran"></param>
        public void ПодтвердитьТранзакцию(DbTransaction tran)
        {
            tran.Commit();
        }
        /// <summary>
        /// NT-Собрать строку подключения
        /// </summary>
        /// <param name="server">Адрес сервера</param>
        /// <param name="user">Логин пользователя</param>
        /// <param name="password">Пароль пользователя</param>
        /// <param name="database">Имя базы данных</param>
        /// <param name="timeout">Таймаут соединения в секундах</param>
        /// <returns></returns>
        public static String CreateConnectionString(string server, string user, string password, string database, Int32 timeout)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = server;
            builder.UserID = user;
            builder.UseAffectedRows = true;
            builder.Password = password;
            builder.Database = database;
            builder.ConnectionTimeout = (UInt32)timeout;
            return builder.ConnectionString;
        }
        #endregion

        #region *** Функции создания таблиц ***
        /// <summary>
        /// NT - Удалить таблицу из БД. Если таблица не существует, функция завершается успешно.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void DeleteTable(String tablename, int timeout)
        {
            String q = String.Format("DROP TABLE IF EXISTS `{0}`;", tablename);
            this.ExecuteNonQuery(q, timeout);

            return;
        }

        /// <summary>
        /// NT - Создать индексы таблицы БД. 
        /// Индексы следует создавать после массовой загрузки строк, иначе загрузка будет медленной.
        /// </summary>
        /// <param name="tableName">Имя таблицы</param>
        /// <param name="indexName">Имя создаваемого индекса</param>
        /// <param name="columnName">Имя индексируемого столбца</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void CreateTableIndex(String tableName, String indexName, String columnName, int timeout)
        {
            String q = String.Format("ALTER TABLE `{0}` ADD INDEX `{1}`  ( `{2}` )", tableName, indexName, columnName);
            this.ExecuteNonQuery(q, timeout);
        }
        /// <summary>
        /// NT-Удалить индекс таблицы БД
        /// </summary>
        /// <param name="tableName">Имя таблицы</param>
        /// <param name="indexName">Имя удаляемого индекса</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void DeleteTableIndex(String tableName, String indexName, int timeout)
        {
            String q = String.Format("ALTER TABLE `{0}` DROP INDEX `{1}`", tableName, indexName);
            this.ExecuteNonQuery(q, timeout);
        }

        #endregion

#region *** Общие функции таблиц ***

        /// <summary>
        /// NT-Выполнить запрос к БД
        /// </summary>
        /// <param name="query"></param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public Int32 ExecuteNonQuery(String query, int timeout)
        {
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;
            Object ob = cmd.ExecuteScalar(); //Int32 type returned here
            if (ob == null) return 0;
            return Int32.Parse(ob.ToString());//convert to-from string
        }
        /// <summary>
        /// NT-get max of id from specified table
        /// </summary>
        /// <param name="table">table name</param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public Int64 GetMaxIdFromTable(string table, int timeout)
        {
            string query = "SELECT MAX(id) AS id FROM " + table;
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            Object ob = cmd.ExecuteScalar(); //Int32 type returned here
            return Int64.Parse(ob.ToString());//convert to-from string
        }

        /// <summary>
        /// NT-get min of id from specified table
        /// </summary>
        /// <param name="table">table name</param>
        /// <param name="timeout"></param>
        /// <returns></returns>
        public Int64 GetMinIdFromTable(string table, int timeout)
        {
            string query = "SELECT MIN(id) AS id FROM " + table;
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            Object ob = cmd.ExecuteScalar(); //Int32 type returned here
            return Int64.Parse(ob.ToString());//convert to-from string
        }
#endregion

        #region *** Функции таблицы лексем ***

        /// <summary>
        /// NT-Обновить лексему, выбрав ее по id.
        /// </summary>
        /// <param name="tablename">Table name</param>
        /// <param name="lex">Lexem object to update</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 UpdateLexem(String tablename, Lexem lex, Int32 timeout)
        {

            //create command
            if (m_UpdateLexemCmd == null)
            {
                //UPDATE `word` SET `lexid` = '1', `text` = 'ere', `freq` = '9', `typ` = '7',`uflag` = '3',`hash` = 'sd',`comment` = '456' WHERE `id` =641461;

                string query = String.Format("UPDATE `{0}` SET `lexid` = @lexid, `text` = @text,`freq` = @freq,`typ` = @typ,`uflag` = @uflag,`priform` = @priform,`rod` = @rod,`chislo` = @chislo,`padeg` = @padeg,`odushev` = @odushev,`sclontype` = @sclontype,`lico` = @lico,`vremja` = @vremja,`zalog` = @zalog,`vid` = @vid,`naklon` = @naklon,`perehod` = @perehod, `vozvrat` = @vozvrat, `sravn` = @sravn,`form` = @form,`gramval` = @gramval,`useful` = @useful,`hash` = @hash,`comment` = @comment WHERE (`id` = @id);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@lexid", MySqlDbType.Int32);
                cmd.Parameters.Add("@text", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@freq", MySqlDbType.Int32);
                cmd.Parameters.Add("@typ", MySqlDbType.Int32);
                cmd.Parameters.Add("@uflag", MySqlDbType.Int32);
                cmd.Parameters.Add("@priform", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@rod", MySqlDbType.Int32);
                cmd.Parameters.Add("@chislo", MySqlDbType.Int32);
                cmd.Parameters.Add("@padeg", MySqlDbType.Int32);
                cmd.Parameters.Add("@odushev", MySqlDbType.Int32);
                cmd.Parameters.Add("@sclontype", MySqlDbType.Int32);
                cmd.Parameters.Add("@lico", MySqlDbType.Int32);
                cmd.Parameters.Add("@vremja", MySqlDbType.Int32);
                cmd.Parameters.Add("@zalog", MySqlDbType.Int32);
                cmd.Parameters.Add("@vid", MySqlDbType.Int32);
                cmd.Parameters.Add("@naklon", MySqlDbType.Int32);
                cmd.Parameters.Add("@perehod", MySqlDbType.Int32);
                cmd.Parameters.Add("@vozvrat", MySqlDbType.Int32);
                cmd.Parameters.Add("@sravn", MySqlDbType.Int32);
                cmd.Parameters.Add("@form", MySqlDbType.Int32);
                cmd.Parameters.Add("@gramval", MySqlDbType.Int32);
                cmd.Parameters.Add("@useful", MySqlDbType.Int32);
                cmd.Parameters.Add("@hash", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@comment", MySqlDbType.VarChar, 32767);
                cmd.Parameters.Add("@id", MySqlDbType.Int32); //table id for WHERE
                //store to variable
                this.m_UpdateLexemCmd = cmd;
            }
            //execute command
            this.m_UpdateLexemCmd.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_UpdateLexemCmd; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = lex.m_lexid;
            c.Parameters[1].Value = lex.m_text;
            c.Parameters[2].Value = lex.m_freq;
            c.Parameters[3].Value = lex.m_type;
            c.Parameters[4].Value = lex.m_userflag;
            c.Parameters[5].Value = lex.m_primaryForm;
            c.Parameters[6].Value = lex.m_rod;
            c.Parameters[7].Value = lex.m_chislo;
            c.Parameters[8].Value = lex.m_padeg;
            c.Parameters[9].Value = lex.m_odushev;
            c.Parameters[10].Value = lex.m_sklontype;
            c.Parameters[11].Value = lex.m_lico;
            c.Parameters[12].Value = lex.m_vremja;
            c.Parameters[13].Value = lex.m_zalog;
            c.Parameters[14].Value = lex.m_vid;
            c.Parameters[15].Value = lex.m_naklon;
            c.Parameters[16].Value = lex.m_perehod;
            c.Parameters[17].Value = lex.m_vozvrat;
            c.Parameters[18].Value = lex.m_sravnenie;
            c.Parameters[19].Value = lex.m_form;
            c.Parameters[20].Value = lex.m_gramval;
            c.Parameters[21].Value = lex.m_useful;
            c.Parameters[22].Value = lex.m_hash;
            c.Parameters[23].Value = lex.m_comment;
            c.Parameters[24].Value = lex.m_id; //table id for WHERE
            //execute command
            return c.ExecuteNonQuery();
        }

        /// <summary>
        /// NT-Insert lexem to table word
        /// </summary>
        /// <param name="tablename">Table name</param>
        /// <param name="lex">Lexem object to insert</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 InsertLexem(String tablename, Lexem lex, Int32 timeout)
        {
            //create command
            if (m_InsertToLexemCmd1 == null)
            {
                string query = String.Format("INSERT INTO `{0}` (`lexid`, `text`,`freq`,`typ`,`uflag`,`priform`,`rod`,`chislo`,`padeg`,`odushev`,`sclontype`,`lico`,`vremja`,`zalog`,`vid`,`naklon`,`perehod`, `vozvrat`, `sravn`,`form`,`gramval`,`useful`,`hash`,`comment`) VALUES (@lexid, @text, @freq, @typ, @uflag, @priform, @rod, @chislo, @padeg, @odushev, @sclontype, @lico, @vremja, @zalog, @vid, @naklon, @perehod, @vozvrat, @sravn, @form, @gramval, @useful, @hash, @comment);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@lexid", MySqlDbType.Int32);                
                cmd.Parameters.Add("@text", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@freq", MySqlDbType.Int32);
                cmd.Parameters.Add("@typ", MySqlDbType.Int32);
                cmd.Parameters.Add("@uflag", MySqlDbType.Int32);
                cmd.Parameters.Add("@priform", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@rod", MySqlDbType.Int32);
                cmd.Parameters.Add("@chislo", MySqlDbType.Int32);
                cmd.Parameters.Add("@padeg", MySqlDbType.Int32);
                cmd.Parameters.Add("@odushev", MySqlDbType.Int32);
                cmd.Parameters.Add("@sclontype", MySqlDbType.Int32);
                cmd.Parameters.Add("@lico", MySqlDbType.Int32);
                cmd.Parameters.Add("@vremja", MySqlDbType.Int32);
                cmd.Parameters.Add("@zalog", MySqlDbType.Int32);
                cmd.Parameters.Add("@vid", MySqlDbType.Int32);
                cmd.Parameters.Add("@naklon", MySqlDbType.Int32);
                cmd.Parameters.Add("@perehod", MySqlDbType.Int32);
                cmd.Parameters.Add("@vozvrat", MySqlDbType.Int32);
                cmd.Parameters.Add("@sravn", MySqlDbType.Int32);
                cmd.Parameters.Add("@form", MySqlDbType.Int32);
                cmd.Parameters.Add("@gramval", MySqlDbType.Int32);
                cmd.Parameters.Add("@useful", MySqlDbType.Int32);
                cmd.Parameters.Add("@hash", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@comment", MySqlDbType.VarChar, 32767);
                //store to variable
                this.m_InsertToLexemCmd1 = cmd;
            }
            //execute command
            this.m_InsertToLexemCmd1.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_InsertToLexemCmd1; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = lex.m_lexid;
            c.Parameters[1].Value = lex.m_text;
            c.Parameters[2].Value = lex.m_freq;
            c.Parameters[3].Value = lex.m_type;
            c.Parameters[4].Value = lex.m_userflag;
            c.Parameters[5].Value = lex.m_primaryForm;
            c.Parameters[6].Value = lex.m_rod;
            c.Parameters[7].Value = lex.m_chislo;
            c.Parameters[8].Value = lex.m_padeg;
            c.Parameters[9].Value = lex.m_odushev;
            c.Parameters[10].Value = lex.m_sklontype;
            c.Parameters[11].Value = lex.m_lico;
            c.Parameters[12].Value = lex.m_vremja;
            c.Parameters[13].Value = lex.m_zalog;
            c.Parameters[14].Value = lex.m_vid;
            c.Parameters[15].Value = lex.m_naklon;
            c.Parameters[16].Value = lex.m_perehod;
            c.Parameters[17].Value = lex.m_vozvrat;
            c.Parameters[18].Value = lex.m_sravnenie;
            c.Parameters[19].Value = lex.m_form;
            c.Parameters[20].Value = lex.m_gramval;
            c.Parameters[21].Value = lex.m_useful;
            c.Parameters[22].Value = lex.m_hash;
            c.Parameters[23].Value = lex.m_comment;
            //execute command
            return c.ExecuteNonQuery();
        }

        /// <summary>
        /// NR-Выбрать лексемы как часть общего диапазона  
        /// </summary>
        /// <param name="table">Имя таблицы</param>
        /// <param name="fromId">Начальный id первичный ключ диапазона таблицы</param>
        /// <param name="count">Число строк для чтения</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает список лексем</returns>
        public List<Lexem> GetLexems(string table, long fromId, int count, int timeout)
        {
            //create command
            string query = String.Format("SELECT * FROM {0} WHERE ((`id` >= {1}) AND (`id` < {2}))", table, fromId, fromId + count);
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;//set command timeout
            //execute command
            MySqlDataReader rdr = cmd.ExecuteReader();
            List<Lexem> lx = readLexemList(rdr);
            //close and return;
            rdr.Close();
            return lx;
        }

        /// <summary>
        /// NT-Выбрать лексемы по заданному WHERE
        /// </summary>
        /// <param name="table">Имя таблицы</param>
        /// <param name="wherePart">часть SQL-запроса после WHERE</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает список лексем</returns>
        public List<Lexem> GetLexems(string table, string wherePart, int timeout)
        {
            //create command
            string query = String.Format("SELECT * FROM `{0}` WHERE ({1})", table, wherePart);
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;//set command timeout
            //execute command
            MySqlDataReader rdr = cmd.ExecuteReader();
            List<Lexem> lx = readLexemList(rdr);
            //close and return;
            rdr.Close();
            return lx;



        }

        /// <summary>
        /// NT-Собрать выборку из MySqlDataReader в список лексем. Не закрывает MySqlDataReader объект.
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>
        private static List<Lexem> readLexemList(MySqlDataReader rdr)
        {
            List<Lexem> lexemList = new List<Lexem>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    //create lexem
                    Lexem lex = new Lexem();
                    //read fields
                    lex.m_id = rdr.GetInt32(0);
                    lex.m_lexid = rdr.GetInt32(1);
                    lex.m_text = rdr.GetString(2);
                    lex.m_freq = rdr.GetInt32(3);
                    lex.m_type = (КлассЛексемы)rdr.GetInt32(4);
                    lex.m_userflag = rdr.GetInt32(5);
                    lex.m_primaryForm = rdr.GetString(6);
                    lex.m_rod = (Род)rdr.GetInt32(7);
                    lex.m_chislo = (Число)rdr.GetInt32(8);
                    lex.m_padeg = (Падеж)rdr.GetInt32(9);
                    lex.m_odushev = (Одушевленность)rdr.GetInt32(10);
                    lex.m_sklontype = (ТипСклонения)rdr.GetInt32(11);
                    lex.m_lico = (Лицо)rdr.GetInt32(12);
                    lex.m_vremja = (Время)rdr.GetInt32(13);
                    lex.m_zalog = (Залог)rdr.GetInt32(14);
                    lex.m_vid = (Вид)rdr.GetInt32(15);
                    lex.m_naklon = (Наклонение)rdr.GetInt32(16);
                    lex.m_perehod = (Переходность)rdr.GetInt32(17);
                    lex.m_vozvrat = (Возвратность)rdr.GetInt32(18);
                    lex.m_sravnenie = (СтепеньСравнения)rdr.GetInt32(19);
                    lex.m_form = (Полнота)rdr.GetInt32(20);
                    lex.m_gramval = (Разряд)rdr.GetInt32(21);
                    lex.m_useful = (Применение)rdr.GetInt32(22);
                    lex.m_hash = rdr.GetString(23);//load hash from table
                    lex.m_comment = rdr.GetString(24);
                    //put lexem to output list
                    lexemList.Add(lex);
                }
            }
            return lexemList;
        }

                /// <summary>
        /// NT - Создать таблицу словоформ в БД. Исключение, если таблица уже существует.
        /// Индексы надо создавать отдельно.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void CreateLexemTable(String tablename, int timeout)
        {
            String f = "CREATE TABLE `{0}` ( `id` int(11) NOT NULL auto_increment, `lexid` int(11) default '0', `text` varchar(64) collate utf8_bin NOT NULL, `freq` int(11) default '0', `typ` int(11) default '0', `uflag` int(11) default '0', `priform` varchar(64) collate utf8_bin default NULL, `rod` int(11) default '0', `chislo` int(11) default '0', `padeg` int(11) default '0', `odushev` int(11) default '0', `sclontype` int(11) default '0', `lico` int(11) default '0', `vremja` int(11) default '0', `zalog` int(11) default '0', `vid` int(11) default '0', `naklon` int(11) default '0', `perehod` int(11) default '0', `vozvrat` int(11) default '0', `sravn` int(11) default '0', `form` int(11) default '0', `gramval` int(11) default '0', `useful` int(11) default '0', `hash` varchar(64) collate utf8_bin default NULL, `comment` mediumtext collate utf8_bin, PRIMARY KEY  (`id`)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_bin PACK_KEYS=0 AUTO_INCREMENT=1 ;";
            String q = String.Format(f, tablename);//вставить имя таблицы
            this.ExecuteNonQuery(q, timeout);

            return;
        }

        /// <summary>
        /// NT - Создать индексы таблицы словоформ в БД. 
        /// Индексы следует создавать после массовой загрузки строк, иначе загрузка будет медленной.
        /// Создание индексов на 1млн строк может занять более 100 секунд, поэтому задайте достаточный таймаут.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void CreateLexemTableIndex(String tablename, int timeout)
        {
            CreateTableIndex(tablename, "Index_text", "text", timeout);
            CreateTableIndex(tablename, "Index_hash", "hash", timeout);
            CreateTableIndex(tablename, "Index_priform", "priform", timeout);
            return;
        }

        /// <summary>
        /// NT - Удалить индексы таблицы словоформ в БД. 
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void DeleteLexemTableIndex(String tablename, int timeout)
        {
            DeleteTableIndex(tablename, "Index_text", timeout);
            DeleteTableIndex(tablename, "Index_hash", timeout);
            DeleteTableIndex(tablename, "Index_priform", timeout);
            return;
        }


        #endregion

        #region *** Функции таблицы связей ***
        /// <summary>
        /// NT-Обновить связь, выбрав ее по id.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="link">Link object to update</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 UpdateLink(String tablename, Link link, Int32 timeout)
        {
            //create command
            if (m_UpdateLinkCmd == null)
            {
                string query = String.Format("UPDATE `{0}` SET `linkid` = @linkid, `srcid` = @srcid,`srcword` = @srcword,`linktype` = @linktype,`dstid` = @dstid,`dstword` = @dstword,`comment` = @comment,`userflag` = @userflag WHERE (`id` = @id);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@linkid", MySqlDbType.Int32);
                cmd.Parameters.Add("@srcid", MySqlDbType.Int32);
                cmd.Parameters.Add("@srcword", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@linktype", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@dstid", MySqlDbType.Int32);
                cmd.Parameters.Add("@dstword", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@comment", MySqlDbType.VarChar, 32767);
                cmd.Parameters.Add("@userflag", MySqlDbType.Int32);
                cmd.Parameters.Add("@id", MySqlDbType.Int32);//for WHERE
                //store to variable
                this.m_UpdateLinkCmd = cmd;
            }
            //execute command
            this.m_UpdateLinkCmd.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_UpdateLinkCmd; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = link.m_linkid;
            c.Parameters[1].Value = link.m_srcLexId;
            c.Parameters[2].Value = link.m_srcLex;
            c.Parameters[3].Value = link.m_linktype;
            c.Parameters[4].Value = link.m_dstLexId;
            c.Parameters[5].Value = link.m_dstLex;
            c.Parameters[6].Value = link.m_comment;
            c.Parameters[7].Value = link.m_userflag;
            c.Parameters[8].Value = link.m_id;//for WHERE
            //execute command
            return c.ExecuteNonQuery();
        }
        /// <summary>
        /// NT-Insert link to table
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="link">Link object to insert</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 InsertLink(String tablename, Link link, Int32 timeout)
        {
            //create command
            if (m_InsertToLinkCmd == null)
            {
                string query = String.Format("INSERT INTO `{0}` (`linkid`, `srcid`,`srcword`,`linktype`,`dstid`,`dstword`,`comment`,`userflag`) VALUES ( @linkid, @srcid, @srcword, @linktype, @dstid, @dstword, @comment, @userflag);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@linkid", MySqlDbType.Int32);
                cmd.Parameters.Add("@srcid", MySqlDbType.Int32);
                cmd.Parameters.Add("@srcword", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@linktype", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@dstid", MySqlDbType.Int32);
                cmd.Parameters.Add("@dstword", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@comment", MySqlDbType.VarChar, 32767);
                cmd.Parameters.Add("@userflag", MySqlDbType.Int32);

                //store to variable
                this.m_InsertToLinkCmd = cmd;
            }
            //execute command
            this.m_InsertToLinkCmd.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_InsertToLinkCmd; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = link.m_linkid;
            c.Parameters[1].Value = link.m_srcLexId;
            c.Parameters[2].Value = link.m_srcLex;
            c.Parameters[3].Value = link.m_linktype;
            c.Parameters[4].Value = link.m_dstLexId;
            c.Parameters[5].Value = link.m_dstLex;
            c.Parameters[6].Value = link.m_comment;
            c.Parameters[7].Value = link.m_userflag;
            //execute command
            return c.ExecuteNonQuery();
        }

        /// <summary>
        /// NT-Выбрать связи по заданному WHERE
        /// </summary>
        /// <param name="table">Имя таблицы</param>
        /// <param name="wherePart">часть SQL-запроса после WHERE</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает список связей</returns>
        public List<Link> GetLinks(string table, string wherePart, int timeout)
        {
            //create command
            string query = String.Format("SELECT * FROM `{0}` WHERE ({1})", table, wherePart);
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;//set command timeout
            //execute command
            MySqlDataReader rdr = cmd.ExecuteReader();
            List<Link> lx = readLinkList(rdr);
            //close and return;
            rdr.Close();
            return lx;
        }

        /// <summary>
        /// NT-Выбрать связи как часть общего диапазона  
        /// </summary>
        /// <param name="table">Имя таблицы</param>
        /// <param name="fromId">Начальный id первичный ключ диапазона таблицы</param>
        /// <param name="count">Число строк для чтения</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает список лексем</returns>
        public List<Link> GetLinks(string table, long fromId, int count, int timeout)
        {
            //create command
            string query = String.Format("SELECT * FROM {0} WHERE ((`id` >= {1}) AND (`id` < {2}))", table, fromId, fromId + count);
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;//set command timeout
            //execute command
            MySqlDataReader rdr = cmd.ExecuteReader();
            List<Link> lx = readLinkList(rdr);
            //close and return;
            rdr.Close();
            return lx;

        }

        /// <summary>
        /// NT-Собрать выборку из MySqlDataReader в список связей. Не закрывает MySqlDataReader объект.
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>
        private static List<Link> readLinkList(MySqlDataReader rdr)
        {
            List<Link> linkList = new List<Link>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    //create lexem
                    Link lex = new Link();
                    //read fields
                    lex.m_id = rdr.GetInt32(0);
                    lex.m_linkid = rdr.GetInt32(1);
                    lex.m_srcLexId = rdr.GetInt32(2);
                    lex.m_srcLex = rdr.GetString(3);
                    lex.m_linktype = rdr.GetString(4);
                    lex.m_dstLexId = rdr.GetInt32(5);
                    lex.m_dstLex = rdr.GetString(6);
                    lex.m_comment = rdr.GetString(7);
                    lex.m_userflag = rdr.GetInt32(8);

                    //put lexem to output list
                    linkList.Add(lex);
                }
            }
            return linkList;
        }

        /// <summary>
        /// NT-Создать таблицу связей в БД. Исключение, если таблица уже существует.
        /// Индексы надо создавать отдельно.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void CreateLinkTable(String tablename, int timeout)
        {

            String f = "CREATE TABLE `{0}` (`id` int(11) NOT NULL auto_increment,  `linkid` int(11) NOT NULL default '0',  `srcid` int(11) NOT NULL default '0',  `srcword` varchar(64) collate utf8_bin default NULL,  `linktype` varchar(64) collate utf8_bin default NULL,  `dstid` int(11) NOT NULL default '0',  `dstword` varchar(64) collate utf8_bin default NULL, `comment` mediumtext collate utf8_bin, `userflag` int(11) NOT NULL default '0', PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='word relations table' AUTO_INCREMENT=1 ;";
            String q = String.Format(f, tablename);//вставить имя таблицы
            this.ExecuteNonQuery(q, timeout);

            return;
        }

        /// <summary>
        /// NT-Создать индексы таблицы связей в БД. 
        /// Индексы следует создавать после массовой загрузки строк, иначе загрузка будет медленной.
        /// Создание индексов на 1млн строк может занять более 100 секунд, поэтому задайте достаточный таймаут.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void CreateLinkTableIndex(String tablename, int timeout)
        {
            CreateTableIndex(tablename, "Index_SrcWord", "srcword", timeout);
            CreateTableIndex(tablename, "Index_DestWord", "dstword", timeout);
            CreateTableIndex(tablename, "Index_linktype ", "linktype", timeout);
            //return;
        }

        /// <summary>
        /// NT-Удалить индексы таблицы связей в БД. 
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void DeleteLinkTableIndex(String tablename, int timeout)
        {
            DeleteTableIndex(tablename, "Index_SrcWord", timeout);
            DeleteTableIndex(tablename, "Index_DestWord", timeout);
            DeleteTableIndex(tablename, "Index_linktype", timeout);
            return;
        }

        #endregion

        #region *** Функции таблицы частотного словаря  - неоптимальны для применения ***
        /// <summary>
        /// NT-Обновить элемент частотного словаря, выбрав его по id.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="link">Freq object to update</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 FreqUpdate(String tablename, Freq link, Int32 timeout)
        {
            //create command
            if (m_UpdateFreqCmd == null)
            {
                string query = String.Format("UPDATE `{0}` SET `w` = @w, `c` = @c WHERE (`id` = @id);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@w", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@c", MySqlDbType.Int32);
                cmd.Parameters.Add("@id", MySqlDbType.Int32);//for WHERE
                //store to variable
                this.m_UpdateFreqCmd = cmd;
            }
            //execute command
            this.m_UpdateFreqCmd.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_UpdateFreqCmd; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = link.m_Text;
            c.Parameters[1].Value = link.m_Count;
            c.Parameters[2].Value = link.m_id;//for WHERE
            //execute command
            return c.ExecuteNonQuery();
        }

        /// <summary>
        /// NT-Обновить счетчик элемента частотного словаря
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="text">Текст изменяемого элемента</param>
        /// <param name="newCount">Новое значение счетчика лексемы</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 FreqUpdate(String tablename, String text, Int32 newCount, Int32 timeout)
        {
            //create command
            if (m_UpdateFreqCmd == null)
            {
                string query = String.Format("UPDATE `{0}` SET `c` = @c WHERE (`w` = @w);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@w", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@c", MySqlDbType.Int32);
                //store to variable
                this.m_UpdateFreqCmd = cmd;
            }
            //execute command
            this.m_UpdateFreqCmd.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_UpdateFreqCmd; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = text;
            c.Parameters[1].Value = newCount;
            //execute command
            return c.ExecuteNonQuery();
        }

        /// <summary>
        /// NT-Insert freq record to table
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="fr">Freq object to insert</param>
        /// <param name="timeout">Command timeout</param>
        public Int32 FreqInsert(String tablename, Freq fr, Int32 timeout)
        {
            //create command
            if (m_InsertToFreqCmd == null)
            {
                string query = String.Format("INSERT INTO `{0}` (`w`, `c`) VALUES ( @w, @c);", tablename);
                MySqlCommand cmd = new MySqlCommand(query, m_connection);
                cmd.Parameters.Add("@w", MySqlDbType.VarChar, 64);
                cmd.Parameters.Add("@c", MySqlDbType.Int32);

                //store to variable
                this.m_InsertToFreqCmd = cmd;
            }
            //execute command
            this.m_InsertToFreqCmd.CommandTimeout = timeout; //set command timeout
            MySqlCommand c = this.m_InsertToFreqCmd; //make alias for quick typing
            //put data to parameters
            c.Parameters[0].Value = fr.m_Text;
            c.Parameters[1].Value = fr.m_Count;

            //execute command
            return c.ExecuteNonQuery();
        }

        /// <summary>
        /// NT-Получить элемент словаря по его тексту
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="text">Текст лексемы</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает объект элемента частотного словаря</returns>
        public List<Freq> FreqGetFreqList(String tablename, String text, Int32 timeout)
        {


                //create command
                if (m_FreqGetCmd == null)
                {
                    string query = String.Format("SELECT * FROM `{0}` WHERE(`w` = @w);", tablename);
                    MySqlCommand cmd = new MySqlCommand(query, m_connection);
                    cmd.Parameters.Add("@w", MySqlDbType.VarChar, 64);
                    //store to variable
                    this.m_FreqGetCmd = cmd;
                }
                //execute command
                this.m_FreqGetCmd.CommandTimeout = timeout; //set command timeout
                MySqlCommand c = m_FreqGetCmd; //make alias for quick typing
                //put data to parameters
                c.Parameters[0].Value = text;
                //execute command
                MySqlDataReader rdr = c.ExecuteReader();
                List<Freq> result = readFreqList(rdr);
                //close and return;
                rdr.Close();
                return result;
        }

        /// <summary>
        /// NT-Получить элемент словаря по его тексту
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="text">Текст лексемы</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает объект элемента частотного словаря</returns>
        public Freq FreqGet(String tablename, String text, Int32 timeout)
        {
                List<Freq> result = FreqGetFreqList(tablename, text, timeout);
                if(result.Count == 0) return null;
                else return result[0];
        }


        /// <summary>
        /// NT-Выбрать элементы частотного словаря по заданному WHERE
        /// </summary>
        /// <param name="table">Имя таблицы</param>
        /// <param name="wherePart">часть SQL-запроса после WHERE</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает список элементов</returns>
        public List<Freq> FreqGetFreqs(string table, string wherePart, int timeout)
        {
            //create command
            string query = String.Format("SELECT * FROM `{0}` WHERE ({1})", table, wherePart);
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;//set command timeout
            //execute command
            MySqlDataReader rdr = cmd.ExecuteReader();
            List<Freq> lx = readFreqList(rdr);
            //close and return;
            rdr.Close();
            return lx;
        }



        /// <summary>
        /// NT-Выбрать элементы частотного словаря как часть общего диапазона  
        /// </summary>
        /// <param name="table">Имя таблицы</param>
        /// <param name="fromId">Начальный id первичный ключ диапазона таблицы</param>
        /// <param name="count">Число строк для чтения</param>
        /// <param name="timeout">Таймаут в секундах</param>
        /// <returns>Возвращает список элементов</returns>
        public List<Freq> FreqGetFreqs(string table, long fromId, int count, int timeout)
        {
            //create command
            string query = String.Format("SELECT * FROM {0} WHERE ((`id` >= {1}) AND (`id` < {2}))", table, fromId, fromId + count);
            MySqlCommand cmd = new MySqlCommand(query, this.m_connection);
            cmd.CommandTimeout = timeout;//set command timeout
            //execute command
            MySqlDataReader rdr = cmd.ExecuteReader();
            List<Freq> lx = readFreqList(rdr);
            //close and return;
            rdr.Close();
            return lx;

        }

        /// <summary>
        /// NT-Собрать выборку из MySqlDataReader в список частотного словаря. Не закрывает MySqlDataReader объект.
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>
        private static List<Freq> readFreqList(MySqlDataReader rdr)
        {
            List<Freq> freqList = new List<Freq>();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    //create lexem
                    Freq lex = new Freq();
                    //read fields
                    lex.m_id = rdr.GetInt32(0);
                    lex.m_Text = rdr.GetString(1);
                    lex.m_Count = rdr.GetInt32(2);

                    //put lexem to output list
                    freqList.Add(lex);
                }
            }
            return freqList;
        }

        /// <summary>
        /// NT-Создать таблицу частотного словаря в БД. Исключение, если таблица уже существует.
        /// Индексы надо создавать отдельно.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void FreqCreateTable(String tablename, int timeout)
        {
            String f = "CREATE TABLE `{0}` (`id` int(11) NOT NULL auto_increment,  `w` varchar(50) collate utf8_bin NOT NULL, `c` int(10) NOT NULL, PRIMARY KEY (`id`)) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_bin PACK_KEYS=0 AUTO_INCREMENT=1 ;";
            String q = String.Format(f, tablename);//вставить имя таблицы
            this.ExecuteNonQuery(q, timeout);

            return;
        }

        /// <summary>
        /// NT-Создать индексы таблицы связей в БД. 
        /// Индексы следует создавать после массовой загрузки строк, иначе загрузка будет медленной.
        /// Создание индексов на 1млн строк может занять более 100 секунд, поэтому задайте достаточный таймаут.
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void FreqCreateIndex(String tablename, int timeout)
        {
            CreateTableIndex(tablename, "Index_w", "w", timeout);
            //return;
        }

        /// <summary>
        /// NT-Удалить индексы таблицы связей в БД. 
        /// </summary>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="timeout">Таймаут операции в секундах</param>
        public void FreqDeleteIndex(String tablename, int timeout)
        {
            DeleteTableIndex(tablename, "Index_w", timeout);

            return;
        }

        #endregion



        ///// <summary>
        ///// NT-Посчитать число лексем в таблице, по тексту, типу лексемы и первичной форме лексемы.
        ///// </summary>
        ///// <param name="lex"></param>
        ///// <param name="timeout"></param>
        ///// <returns></returns>
        //public Int64 CountLexemInTableWord(Lexem lex, int timeout)
        //{
        //    //create command
        //    if (m_InsertToLexemCmd1 == null)
        //    {
        //        string query = "SELECT COUNT(id) FROM `word` WHERE ((`text` = @text) AND (`typ` = @typ) AND (`priform` = @priform))";
        //        MySqlCommand cmd = new MySqlCommand(query, m_connection);
        //        cmd.Parameters.Add("@text", MySqlDbType.VarChar, 64);
        //        cmd.Parameters.Add("@typ", MySqlDbType.Int32);
        //        cmd.Parameters.Add("@priform", MySqlDbType.VarChar, 64);
        //        //store to variable
        //        this.m_CountWordCmd1 = cmd;
        //    }
        //    //execute command
        //    this.m_CountWordCmd1.CommandTimeout = timeout; //set command timeout
        //    MySqlCommand c = this.m_CountWordCmd1; //make alias for quick typing
        //    //put data to parameters
        //    c.Parameters[0].Value = lex.m_text;
        //    c.Parameters[1].Value = lex.m_type;
        //    c.Parameters[2].Value = lex.m_primaryForm;
        //    //execute command
        //    //конвертим в строку и назад, так как иначе проблема приведения типа
        //    //Object ob = c.ExecuteScalar();
        //    //Type t = ob.GetType();//System.Int64
        //    //return ob; // Int32.Parse(ob.ToString());
        //    return (Int64) c.ExecuteScalar();
        //}


    }
}
