﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlTypes;

namespace Mary
{
    /// <summary>
    /// Represent layer for database
    /// </summary>
    public class MDbLayer
    {

 
        ///// <summary>
        ///// SQLCommand for tests
        ///// </summary>
        //private SqlCommand Cmd_Test;
        ///// <summary>
        ///// SQLCommand for tests
        ///// </summary>
        //private SqlCommand Cmd_TestR;


        private SqlCommand Cmd_getBandCell;
        private SqlCommand Cmd_getCellExists;
        private SqlCommand Cmd_getMaxCellID;
        private SqlCommand Cmd_insertCellTable;
        private SqlCommand Cmd_updateCellTable;
        private SqlCommand Cmd_getCellData;
        private SqlCommand Cmd_setCellData;
        private SqlCommand Cmd_updateLinkTable;
        private SqlCommand Cmd_insertLinkTable;
        private SqlCommand Cmd_getCellLinks;
        private SqlCommand Cmd_deleteLinkById;
        private SqlCommand Cmd_getLinkId;
        private SqlCommand Cmd_getLastLinksIdentity;
        private SqlCommand Cmd_getBandLink;
        //Add more commands here...

















        //public int InsertTestRow(string name, byte[] Value)
        //{
        //    string query = "INSERT INTO TestTable (name, val) VALUES (@name, @val)";
        //    if (Cmd_Test == null)
        //    {
        //        //create command
        //        Cmd_Test = new SqlCommand(query, m_connection);
        //        Cmd_Test.CommandType = CommandType.Text;
        //        Cmd_Test.Parameters.Add("@name", SqlDbType.NVarChar);
        //        Cmd_Test.Parameters.Add("@val", SqlDbType.VarBinary);
        //    }
        //    //execute command
        //    Cmd_Test.CommandTimeout = m_Timeout;
        //    Cmd_Test.Parameters[0].Value = name;
        //    Cmd_Test.Parameters[1].Value = Value;

        //    Cmd_Test.ExecuteNonQuery();

        //    return 0;
        //}

        //public byte[] GetTestRow(string name)
        //{

        //    string query = "SELECT val FROM TestTable WHERE (name = @name)";
        //    SqlBinary res;
            
        //    if (Cmd_TestR == null)
        //    {
        //        //create command
        //        Cmd_TestR = new SqlCommand(query, m_connection);
        //        Cmd_TestR.CommandType = CommandType.Text;
        //        Cmd_TestR.Parameters.Add("@name", SqlDbType.NVarChar);
        //    }
        //    //execute command
        //    Cmd_TestR.CommandTimeout = m_Timeout;
        //    Cmd_TestR.Parameters[0].Value = name;

        //    SqlDataReader rdr = Cmd_TestR.ExecuteReader();
        //    //iterate and select timezones
        //    if (rdr.HasRows == true)
        //    {
        //       while (rdr.Read())
        //        {
        //            //get data from row
        //            res = rdr.GetSqlBinary(0);

        //        }
        //    }
        //    rdr.Close();

        //    return res.Value;

        //}








        #region Engine table functions

        /// <summary>
        /// Load first existing container from database. Throw exception if container not found 
        /// </summary>
        /// <param name="container">Container object for loading</param>
        /// <exception cref="SqlException">locked row</exception>
        /// <exception cref="InvalidOperationException">connection is closed</exception>
        internal void LoadContainer(MEngine cont)
        {
            int vers;
            //SELECT EngineTable.* FROM EngineTable
            SqlCommand sc = new SqlCommand("SELECT EngineTable.* FROM EngineTable", m_connection);
            sc.CommandType = CommandType.Text;
            sc.CommandTimeout = m_Timeout;
            SqlDataReader sdr = sc.ExecuteReader();
            if (sdr.HasRows == true)
            {
                while (sdr.Read())
                {
                    vers = sdr.GetInt32(1);
                    if (vers != MVersion.VersionID) throw new Exception("Container version mismatch");
                    cont.SnapshotManager.Step = sdr.GetInt32(2);
                    cont.Log.LogFileNumber = sdr.GetInt32(3); //lognum, ex logname
                    cont.Log.logDetail = (MMessageClass)((uint)sdr.GetInt32(4));
                    cont.Description = sdr.GetString(5);
                    cont.Name = sdr.GetString(6);
                    cont.ServiceFlag = sdr.GetInt32(7);
                    cont.State = new MID(sdr.GetInt32(8));
                    cont.DefaultCellMode = (MCellMode)sdr.GetInt32(9);
                    cont.ContainerID = sdr.GetInt32(10);
                    break; //only first record used
                }
                sdr.Close();
            }
            else
            {
                sdr.Close();
                throw new Exception("Container not found");
            }
        }

        /// <summary>
        /// Save container in database. Create new record if any not exists
        /// </summary>
        /// <param name="container"></param>
        /// <remarks>Без лога, или проверять его существование!</remarks>
        internal void SaveContainer(MEngine container)
        {
            //try update records
            if (updateEngineTable(container) < 1)
                //no any container records in table
                insertEngineTable(container);
        }

        /// <summary>
        /// Update container record
        /// </summary>
        /// <returns> Number of updated rows</returns>
        private int updateEngineTable(MEngine cont)
        {
            string query = "UPDATE EngineTable SET version = @ver, step = @step, lognum = @lname, loglevel = @llevel, descr = @descr, name = @name, sflag = @sflag, state = @state, cellmode = @cellmode, idcon = @idcon";
            //UPDATE EngineTable SET version = @ver, step = @step, dirpath = @path, logname = @lname, loglevel = @llevel, stepname = @sname, descr = @descr, name = @name, sflag = @sflag, state = @state, limiter = @limiter
            //поскольку команда используется сравнительно редко, создаем ее в стеке, экономим память.
            SqlCommand sc = new SqlCommand(query, this.m_connection);
            sc.CommandTimeout = this.m_Timeout;
            sc.CommandType = CommandType.Text;
            sc.Parameters.Add("@ver", SqlDbType.Int);
            sc.Parameters.Add("@step", SqlDbType.Int);
            sc.Parameters.Add("@lname", SqlDbType.Int);
            sc.Parameters.Add("@llevel", SqlDbType.Int);
            sc.Parameters.Add("@descr", SqlDbType.NText);
            sc.Parameters.Add("@name", SqlDbType.NVarChar);
            sc.Parameters.Add("@sflag", SqlDbType.Int);
            sc.Parameters.Add("@state", SqlDbType.Int);
            sc.Parameters.Add("@cellmode", SqlDbType.Int);
            sc.Parameters.Add("@idcon", SqlDbType.Int);

            //add values
            sc.Parameters[0].Value = MVersion.VersionID;
            sc.Parameters[1].Value = cont.SnapshotManager.Step;
            sc.Parameters[2].Value = cont.Log.LogFileNumber; //ex logname
            sc.Parameters[3].Value = (int) cont.Log.logDetail;
            sc.Parameters[4].Value = cont.Description;
            sc.Parameters[5].Value = cont.Name;
            sc.Parameters[6].Value = cont.ServiceFlag;
            sc.Parameters[7].Value = cont.State.ID;
            sc.Parameters[8].Value = (int) cont.DefaultCellMode;
            sc.Parameters[9].Value = cont.ContainerID;
            //execute command
            return sc.ExecuteNonQuery();
        }

        /// <summary>
        /// Insert row in EngineTable
        /// </summary>
        /// <param name="cont"></param>
        private void insertEngineTable(MEngine cont)
        {
            string query = "INSERT INTO EngineTable (version, step, lognum, loglevel, descr, name, sflag, state, cellmode, idcon) VALUES (@ver, @step, @lname, @llevel, @descr, @name, @sflag, @state, @cellmode, @idcon)";
            //INSERT INTO EngineTable (version, step, dirpath, logname, loglevel, stepname, descr, name, sflag, state, limiter) VALUES (23000, 0, N'c:\\dir', N'logname', 0, N'stepname', N'descr', N'namme', 0, 0, '`')
            //поскольку команда используется однократно, создаем ее в стеке, экономим память.
            SqlCommand sc = new SqlCommand(query, this.m_connection);
            sc.CommandTimeout = this.m_Timeout;
            sc.CommandType = CommandType.Text;
            sc.Parameters.Add("@ver", SqlDbType.Int);
            sc.Parameters.Add("@step", SqlDbType.Int);
            sc.Parameters.Add("@lname", SqlDbType.Int);
            sc.Parameters.Add("@llevel", SqlDbType.Int);
            sc.Parameters.Add("@descr", SqlDbType.NText);
            sc.Parameters.Add("@name", SqlDbType.NVarChar);
            sc.Parameters.Add("@sflag", SqlDbType.Int);
            sc.Parameters.Add("@state", SqlDbType.Int);
            sc.Parameters.Add("@cellmode", SqlDbType.Int);
            sc.Parameters.Add("@idcon", SqlDbType.Int);
            //add values
            sc.Parameters[0].Value = MVersion.VersionID;
            sc.Parameters[1].Value = cont.SnapshotManager.Step;
            sc.Parameters[2].Value = cont.Log.LogFileNumber;  //ex logname
            sc.Parameters[3].Value = (int) cont.Log.logDetail;
            sc.Parameters[4].Value = cont.Description;
            sc.Parameters[5].Value = cont.Name;
            sc.Parameters[6].Value = cont.ServiceFlag;
            sc.Parameters[7].Value = cont.State.ID;
            sc.Parameters[8].Value = (int) cont.DefaultCellMode;
            sc.Parameters[9].Value = cont.ContainerID;
            //execute command
            sc.ExecuteNonQuery();

        }

        #endregion

        #region CellSection table functions

        /// <summary>
        /// NT-Проверить, что ячейка с таким идентификатором существует
        /// </summary>
        /// <param name="cellid">cell id</param>
        /// <returns></returns>
        internal bool isCellExists(MID cellid)
        {
            //SELECT CellTable.* FROM CellTable WHERE (cellid = @Param1)
            if (Cmd_getCellExists == null) 
            {
                Cmd_getCellExists = new SqlCommand("SELECT CellTable.cellid FROM CellTable WHERE (cellid = @cid)", m_connection);
                Cmd_getCellExists.CommandTimeout = m_Timeout;
                Cmd_getCellExists.Parameters.Add("@cid", SqlDbType.Int);
            }
            //execute
            Cmd_getCellExists.Parameters[0].Value = cellid.ID;
            SqlDataReader rdr = Cmd_getCellExists.ExecuteReader();//коряво, надо переделать бы на COUNT
            bool res = rdr.HasRows;
            rdr.Close();
            return res;
        }

        /// <summary>
        /// NT-Get cell by id
        /// </summary>
        /// <param name="cellId">CellSection identificator</param>
        /// <param name="largeCell">CellSection mode: False for MCellA, true for MCellB</param>
        /// <returns>MCell object or null if cell not exists</returns>
        internal MCell selectCell(MID cellId, bool largeCell)
        {
            //если MEngine.DefaultCellMode=false требует MCellA, то зачем загружать ячейку из бд?
            //можно просто создать ее и записать ИД. Однако надо проверить, что она существует в таблице.
            //Поэтому переделать код, выделив вариант для MCellA как более простой и быстрый.
            
            //SELECT CellTable.* FROM CellTable WHERE (cellid = @Param1)
            if (Cmd_getCell == null)
            {
                Cmd_getCell = new SqlCommand("SELECT CellTable.* FROM CellTable WHERE (cellid = @cid)", m_connection);
                Cmd_getCell.CommandTimeout = m_Timeout;
                Cmd_getCell.Parameters.Add("@cid", SqlDbType.Int);
            }
            //execute
            Cmd_getCell.Parameters[0].Value = cellId.ID;
            SqlDataReader rdr = Cmd_getCell.ExecuteReader();

            MCell r = null;
            if (rdr.HasRows == true) 
            {
                if (largeCell == false)
                {
                    r = new MCellA();//create small cell
                    r.CellID = cellId;
                }
                else
                {

                    rdr.Read();//read one row from result
                    r = new MCellB(); //create large cell
                    r.CellMode = MCellMode.DelaySave; //disable property saving
                    r.Name = rdr.GetString(1);
                    r.Description = rdr.GetString(2);
                    r.isActive = rdr.GetBoolean(3);
                    r.TypeId = new MID(rdr.GetInt32(4));
                    r.CreaTime = rdr.GetDateTime(5);
                    r.ModiTime = rdr.GetDateTime(6);
                    r.ReadOnly = rdr.GetBoolean(7);
                    r.State = new MID(rdr.GetInt32(8));
                    r.ServiceFlag = rdr.GetInt32(9);
                    r.Value = rdr.GetSqlBinary(10).Value;
                    r.ValueTypeId = new MID(rdr.GetInt32(11));
                    r.CellID = new MID(rdr.GetInt32(12));
                    r.CellMode = MCellMode.Normal; //enable property saving
                }
            }
            rdr.Close();
            return r;
        }

        /// <summary>
        /// NT-Get max of cell id's in table, return 0 if no cells
        /// </summary>
        /// <returns></returns>
        internal int S1_getMaxCellId()
        {
            //SELECT MAX(cellid) AS Expr1 FROM CellTable
            if (Cmd_getMaxCellID == null) 
            {
                Cmd_getMaxCellID = new SqlCommand("SELECT MAX(cellid) AS Expr1 FROM CellTable", m_connection);
                Cmd_getMaxCellID.CommandTimeout = m_Timeout;
            }
            //execute
            SqlDataReader rdr = Cmd_getMaxCellID.ExecuteReader();
            rdr.Read();
            SqlInt32 res =  rdr.GetSqlInt32(0);
            rdr.Close();
            if (res.IsNull) return 0;
            else return res.Value;
        }
        /// <summary>
        /// NFT-Get min of cell id's in table,  return 0 if no cells
        /// </summary>
        /// <returns></returns>
        internal int getMinCellId()
        {
            //create temp command
            SqlCommand cmd = new SqlCommand("SELECT MIN(cellid) AS Expr1 FROM CellTable", m_connection);
            cmd.CommandTimeout = m_Timeout;
            //get result
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            SqlInt32 res = rdr.GetSqlInt32(0);
            rdr.Close();
            if (res.IsNull) return 0;
            else return res.Value;
        }
        /// <summary>
        /// NFT-Get band of cells
        /// </summary>
        /// <param name="rowFrom">cell id from which begin select cells</param>
        /// <param name="rowTo">cell id to (but not include) end select cells</param>
        /// <returns></returns>
        internal List<MCell> getBandOfCellById(int rowFrom, int rowTo)
        {
            if (Cmd_getBandCell == null)
            {
                Cmd_getBandCell = new SqlCommand("SELECT CellTable.* FROM CellTable WHERE ((cellid >= @idfrom) AND (cellid < @idto))", m_connection);
                Cmd_getBandCell.CommandTimeout = m_Timeout;
                Cmd_getBandCell.Parameters.Add("@idfrom", SqlDbType.Int);
                Cmd_getBandCell.Parameters.Add("@idto", SqlDbType.Int);
            }
            //execute
            Cmd_getBandCell.Parameters[0].Value = rowFrom;
            Cmd_getBandCell.Parameters[1].Value = rowTo;
            SqlDataReader rdr = Cmd_getBandCell.ExecuteReader();

            MCell r = null;
            List<MCell> lic = new List<MCell>();
            if (rdr.HasRows == true)
            {
                while(rdr.Read())
                {
                    r = new MCellB(); //create large cell
                    r.CellMode = MCellMode.DelaySave; //disable property saving
                    r.Name = rdr.GetString(1);
                    r.Description = rdr.GetString(2);
                    r.isActive = rdr.GetBoolean(3);
                    r.TypeId = new MID(rdr.GetInt32(4));
                    r.CreaTime = rdr.GetDateTime(5);
                    r.ModiTime = rdr.GetDateTime(6);
                    r.ReadOnly = rdr.GetBoolean(7);
                    r.State = new MID(rdr.GetInt32(8));
                    r.ServiceFlag = rdr.GetInt32(9);
                    r.Value = rdr.GetSqlBinary(10).Value;
                    r.ValueTypeId = new MID(rdr.GetInt32(11));
                    r.CellID = new MID(rdr.GetInt32(12));
                    r.CellMode = MCellMode.Normal; //enable property saving
                    lic.Add(r);
                }
            }
            rdr.Close();
            return lic;
        }

        /// <summary>
        /// insert cell record in table
        /// </summary>
        /// <param name="cell"></param>
        internal int insertCell(MCellB cell)
        {
            string query = "INSERT INTO CellTable (name, descr, active, type, creatime, moditime, ronly, state, sflag, val, valtype, cellid) VALUES (@name,@descr,@active,@type,@creat,@modit,@ronly,@state,@sflag,@val,@valtype,@cid)";
            if (Cmd_insertCellTable == null)
            {
                Cmd_insertCellTable = new SqlCommand(query, m_connection);
                Cmd_insertCellTable.CommandTimeout = m_Timeout;
                Cmd_insertCellTable.Parameters.Add("@name", SqlDbType.NVarChar);
                Cmd_insertCellTable.Parameters.Add("@descr", SqlDbType.NText);
                Cmd_insertCellTable.Parameters.Add("@active", SqlDbType.Bit);
                Cmd_insertCellTable.Parameters.Add("@type", SqlDbType.Int);
                Cmd_insertCellTable.Parameters.Add("@creat", SqlDbType.DateTime);
                Cmd_insertCellTable.Parameters.Add("@modit", SqlDbType.DateTime);
                Cmd_insertCellTable.Parameters.Add("@ronly", SqlDbType.Bit);
                Cmd_insertCellTable.Parameters.Add("@state", SqlDbType.Int);
                Cmd_insertCellTable.Parameters.Add("@sflag", SqlDbType.Int);
                Cmd_insertCellTable.Parameters.Add("@val", SqlDbType.VarBinary);
                Cmd_insertCellTable.Parameters.Add("@valtype", SqlDbType.Int);
                Cmd_insertCellTable.Parameters.Add("@cid", SqlDbType.Int);
            }
            //execute
            Cmd_insertCellTable.Parameters[0].Value = cell.Name;
            Cmd_insertCellTable.Parameters[1].Value = cell.Description;
            Cmd_insertCellTable.Parameters[2].Value = cell.isActive;
            Cmd_insertCellTable.Parameters[3].Value = cell.TypeId.ID;
            Cmd_insertCellTable.Parameters[4].Value = cell.CreaTime;
            Cmd_insertCellTable.Parameters[5].Value = cell.ModiTime;
            Cmd_insertCellTable.Parameters[6].Value = cell.ReadOnly;
            Cmd_insertCellTable.Parameters[7].Value = cell.State.ID;
            Cmd_insertCellTable.Parameters[8].Value = cell.ServiceFlag;
            Cmd_insertCellTable.Parameters[9].Value = cell.Value;
            Cmd_insertCellTable.Parameters[10].Value = cell.ValueTypeId.ID;
            Cmd_insertCellTable.Parameters[11].Value = cell.CellID.ID;
            //return num afected rows
            return Cmd_insertCellTable.ExecuteNonQuery();
        }
        /// <summary>
        /// Update cell record 
        /// </summary>
        /// <param name="cell"></param>
        /// <returns></returns>
        internal int updateCell(MCellB cell)
        {
            //UPDATE CellTable SET name = @name, descr = @descr, active = @active, type = @type, creatime = @creat, moditime = @modit, ronly = @ronly, state = @state, sflag = @sflag, val = @val, valtype = @valtype WHERE (cellid = @cid)
            string query = "UPDATE CellTable SET name = @name, descr = @descr, active = @active, type = @type, creatime = @creat, moditime = @modit, ronly = @ronly, state = @state, sflag = @sflag, val = @val, valtype = @valtype WHERE (cellid = @cid)";
            if (Cmd_updateCellTable == null)
            {
                Cmd_updateCellTable = new SqlCommand(query, m_connection);
                Cmd_updateCellTable.CommandTimeout = m_Timeout;
                Cmd_updateCellTable.Parameters.Add("@name", SqlDbType.NVarChar);
                Cmd_updateCellTable.Parameters.Add("@descr", SqlDbType.NText);
                Cmd_updateCellTable.Parameters.Add("@active", SqlDbType.Bit);
                Cmd_updateCellTable.Parameters.Add("@type", SqlDbType.Int);
                Cmd_updateCellTable.Parameters.Add("@creat", SqlDbType.DateTime);
                Cmd_updateCellTable.Parameters.Add("@modit", SqlDbType.DateTime);
                Cmd_updateCellTable.Parameters.Add("@ronly", SqlDbType.Bit);
                Cmd_updateCellTable.Parameters.Add("@state", SqlDbType.Int);
                Cmd_updateCellTable.Parameters.Add("@sflag", SqlDbType.Int);
                Cmd_updateCellTable.Parameters.Add("@val", SqlDbType.VarBinary);
                Cmd_updateCellTable.Parameters.Add("@valtype", SqlDbType.Int);
                Cmd_updateCellTable.Parameters.Add("@cid", SqlDbType.Int);
            }
            //execute
            Cmd_updateCellTable.Parameters[0].Value = cell.Name;
            Cmd_updateCellTable.Parameters[1].Value = cell.Description;
            Cmd_updateCellTable.Parameters[2].Value = cell.isActive;
            Cmd_updateCellTable.Parameters[3].Value = cell.TypeId.ID;
            Cmd_updateCellTable.Parameters[4].Value = cell.CreaTime;
            Cmd_updateCellTable.Parameters[5].Value = cell.ModiTime;
            Cmd_updateCellTable.Parameters[6].Value = cell.ReadOnly;
            Cmd_updateCellTable.Parameters[7].Value = cell.State.ID;
            Cmd_updateCellTable.Parameters[8].Value = cell.ServiceFlag;
            Cmd_updateCellTable.Parameters[9].Value = cell.Value;
            Cmd_updateCellTable.Parameters[10].Value = cell.ValueTypeId.ID;
            Cmd_updateCellTable.Parameters[11].Value = cell.CellID.ID;
            //return num afected rows
            return Cmd_updateCellTable.ExecuteNonQuery();
        }

        /// <summary>
        /// Save cell data - update or insert row
        /// </summary>
        /// <param name="cell"></param>
        internal void SaveCell(MCellB cell)
        {
            //этот код будет дважды проводить поиск для ячейки, возможно, кэширование на стороне сервера ускорит работу.
            if(isCellExists(cell.CellID))
                updateCell(cell);
            else
                insertCell(cell);

            //этот код будет медленным для новых ячеек
            ////try update record
            //if (updateCell(cell) < 1)
            //    //record not found, create new
            //    insertCell(cell);

        }

        #region get cell functions
        /// <summary>
        /// NT-Get cell description
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal string getCellDescription(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("descr", cellid);
            string res = sdr.GetString(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal string getCellName(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("name", cellid);
            string res = sdr.GetString(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal bool getCellActive(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("active", cellid);
            bool res = sdr.GetBoolean(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal int getCellSFlag(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("sflag", cellid);
            int res = sdr.GetInt32(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal MID getCellState(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("state", cellid);
            MID res = new MID(sdr.GetInt32(0));
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal MID getCellTypeId(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("type", cellid);
            MID res = new MID(sdr.GetInt32(0));
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal DateTime getCellCreaTime(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("creatime", cellid);
            DateTime res = sdr.GetDateTime(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal DateTime getCellModiTime(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("moditime", cellid);
            DateTime res = sdr.GetDateTime(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal bool getCellRonly(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("ronly", cellid);
            bool res = sdr.GetBoolean(0);
            sdr.Close();
            return res;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal byte[] getCellValue(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("val", cellid);
            SqlBinary res = sdr.GetSqlBinary(0);
            sdr.Close();
            return res.Value;
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <returns></returns>
        internal MID getCellValueTypeId(int cellid)
        {
            SqlDataReader sdr = this.getCellColumnDataReader("valtype", cellid);
            MID res = new MID(sdr.GetInt32(0));
            sdr.Close();
            return res;
        }

        /// <summary>
        /// Create data reader for specified column, as part of column access algoritm
        /// </summary>
        /// <param name="columnName"></param>
        /// <param name="cellid">CellSection id</param>
        /// <returns>SqlDataReader, ready to get data, and need to be closed after use</returns>
        private SqlDataReader getCellColumnDataReader(string columnName, int cellid)
        {
            string query = String.Format("SELECT CellTable.{0} FROM CellTable WHERE (cellid = @cid)", columnName);
            //create command
            if (Cmd_getCellData == null)
            {
                Cmd_getCellData = new SqlCommand(query, m_connection);
                Cmd_getCellData.CommandTimeout = m_Timeout;
                Cmd_getCellData.Parameters.Add("@cid", SqlDbType.Int);
            }
            //execute command
            Cmd_getCellData.CommandText = query;
            Cmd_getCellData.Parameters[0].Value = cellid;
            SqlDataReader rdr = Cmd_getCellData.ExecuteReader();
            if (rdr.HasRows == false)
            {
                rdr.Close();
                throw new Exception("CellSection record not found in table");
            }
            else
            {
                rdr.Read();
                //DateTime res = rdr.GetDateTime(0);
                //rdr.Close(); - вынесено в вызывающий код
                return rdr;
            }
        }
#endregion


        #region set cell functions
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellDescription(int cellid, string val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@descr", SqlDbType.NText);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("descr", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellName(int cellid, string val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@name", SqlDbType.NVarChar);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("name", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellActive(int cellid, bool val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@active", SqlDbType.Bit);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("active", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellSFlag(int cellid, int val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@sflag", SqlDbType.Int);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("sflag", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellState(int cellid, MID val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@state", SqlDbType.Int);
            sp.Value =  val.ID;
            //write parameter
            this.setCellColumnData("state", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellTypeId(int cellid, MID val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@type", SqlDbType.Int);
            sp.Value = val.ID;
            //write parameter
            this.setCellColumnData("type", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellCreaTime(int cellid, DateTime val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@creatime", SqlDbType.DateTime);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("creatime", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellRonly(int cellid, bool val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@ronly", SqlDbType.Bit);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("ronly", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellValue(int cellid, byte[] val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@val", SqlDbType.VarBinary);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("val", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellValueTypeId(int cellid, MID val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@valtype", SqlDbType.Int);
            sp.Value = val.ID;
            //write parameter
            this.setCellColumnData("valtype", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }
        /// <summary>
        /// NT-this function throw exception because moditime used twice
        /// </summary>
        /// <param name="cellid"></param>
        /// <param name="val"></param>
        internal void setCellModiTime(int cellid, DateTime val)
        {
            //create parameter
            SqlParameter sp = new SqlParameter("@moditime", SqlDbType.DateTime);
            sp.Value = val;
            //write parameter
            this.setCellColumnData("moditime", sp, cellid);
            //if returns 0, cell not exists. throw exception?
        }

        /// <summary>
        /// Update column in cell record
        /// </summary>
        /// <param name="columnName">Column name</param>
        /// <param name="param">Sql parameter with filled sqldbtype and value fields. </param>
        /// <param name="cellid">midified cell id</param>
        /// <returns>Number of affected rows</returns>
        private int setCellColumnData(string columnName, SqlParameter param, int cellid)
        {
            //UPDATE CellTable SET name = @Param2, moditime = @Param3 WHERE (cellid = @Param1)
            string query = String.Format("UPDATE CellTable SET {0} = @{0}, moditime = @mody WHERE (cellid = @cid)", columnName);
            string paramName = String.Format("@{0}", columnName);
            param.ParameterName = paramName;//для страховки

            //create command
            if (Cmd_setCellData == null)
            {
                Cmd_setCellData = new SqlCommand(query, m_connection);
                Cmd_setCellData.CommandTimeout = m_Timeout;
            }
            //execute command
            Cmd_setCellData.CommandText = query;
            Cmd_setCellData.Parameters.Clear();
            Cmd_setCellData.Parameters.Add(param);
            Cmd_setCellData.Parameters.Add("@mody", SqlDbType.DateTime);
            Cmd_setCellData.Parameters.Add("@cid", SqlDbType.Int);
            Cmd_setCellData.Parameters[1].Value = DateTime.Now;
            Cmd_setCellData.Parameters[2].Value = cellid;
            return Cmd_setCellData.ExecuteNonQuery();
        }


        #endregion


        /// <summary>
        /// NT-Find cells meet specified template. Returned cells is not a part of container and not have links!!! 
        /// </summary>
        /// <param name="tmp">cell template</param>
        /// <param name="largeCells">True - MCellB cells, False - MCellA cells</param>
        /// <returns>Коллекция ячеек, соответствующих шаблону. Временная коллекция, ячейки не загружены в контейнер!</returns>
        internal MCellCollection getCellsByTemplate(MCellTemplate tmp, bool largeCells)
        {
            StringBuilder sb = new StringBuilder();
            //create command, parameters and query
            //SELECT CellTable.* FROM CellTable WHERE (creatime = @Param1) AND (type = @Param2) AND (active = @Param3) AND (descr LIKE @Param4) AND (name = @Param5)
            bool AndFlag = false;//flag for AND word
            SqlParameter sp;
            
            //повторное использование команды не предполагается пока
            SqlCommand alias = new SqlCommand("", m_connection);
            //Создаем текст запроса и параметры
            sb.Append("SELECT CellTable.");
            if (largeCells) sb.Append("*"); else sb.Append("cellid");
            sb.Append(" FROM CellTable WHERE ");

            #region Creating query and parameters
            if (tmp.CellID != null)
            {
                sb.Append("(cellid = @p1)");
                sp = new SqlParameter("@p1", SqlDbType.Int);
                sp.Value = tmp.CellID.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.CreaTime.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(creatime = @p2)");
                sp = new SqlParameter("@p2", SqlDbType.DateTime);
                sp.Value = tmp.CreaTime.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.ModiTime.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(moditime = @p3)");
                sp = new SqlParameter("@p3", SqlDbType.DateTime);
                sp.Value = tmp.ModiTime.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.State != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(state = @p4)");
                sp = new SqlParameter("@p4", SqlDbType.Int);
                sp.Value = tmp.State.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.TypeId != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(type = @p5)");
                sp = new SqlParameter("@p5", SqlDbType.Int);
                sp.Value = tmp.TypeId.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.ValueTypeId != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(valtype = @p6)");
                sp = new SqlParameter("@p6", SqlDbType.Int);
                sp.Value = tmp.ValueTypeId.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.ServiceFlag.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(sflag = @p7)");
                sp = new SqlParameter("@p7", SqlDbType.Int);
                sp.Value = tmp.ServiceFlag.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.Name != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(name = @p8)");
                sp = new SqlParameter("@p8", SqlDbType.NVarChar);
                sp.Value = tmp.Name;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.Description != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(descr LIKE @p9)");
                sp = new SqlParameter("@p9", SqlDbType.NText);
                sp.Value = tmp.Description;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.isActive.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(active = @p10)");
                sp = new SqlParameter("@p10", SqlDbType.Bit);
                sp.Value = tmp.isActive.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.ReadOnly.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(ronly = @p11)");
                sp = new SqlParameter("@p11", SqlDbType.Bit);
                sp.Value = tmp.ReadOnly.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.Value != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(val = @p12)");
                sp = new SqlParameter("@p12", SqlDbType.VarBinary);
                sp.Value = tmp.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            #endregion

            alias.CommandTimeout = m_Timeout; // *5 ?
            alias.CommandText = sb.ToString();
            //execute command
            SqlDataReader rdr = alias.ExecuteReader();
            MCellCollection col = new MCellCollection();
            MCell t;
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    //create cell and fill values
                    if (largeCells)
                    {
                        t = new MCellB();
                        t.CellMode = MCellMode.DelaySave; //disable property saving
                        t.Name = rdr.GetString(1);
                        t.Description = rdr.GetString(2);
                        t.isActive = rdr.GetBoolean(3);
                        t.TypeId = new MID(rdr.GetInt32(4));
                        t.CreaTime = rdr.GetDateTime(5);
                        t.ModiTime = rdr.GetDateTime(6);
                        t.ReadOnly = rdr.GetBoolean(7);
                        t.State = new MID(rdr.GetInt32(8));
                        t.ServiceFlag = rdr.GetInt32(9);
                        t.Value = rdr.GetSqlBinary(10).Value;
                        t.ValueTypeId = new MID(rdr.GetInt32(11));
                        t.CellID = new MID(rdr.GetInt32(12));
                        t.CellMode = MCellMode.Normal; //enable property saving
                    }
                        else
                    {
                        t = new MCellA();
                        t.CellID = new MID( rdr.GetInt32(0));//only cellid need, other come from table
                    }
                    col.S1_AddCell(t);
                }
            }
            rdr.Close();
            return col;
        }

        /// <summary>
        /// NT-Return True if cell table contains cell with specified name 
        /// </summary>
        /// <param name="cellName">Name for check</param>
        /// <returns></returns>
        internal bool CellContainsName(string cellName)
        {
            //create temp command
            SqlCommand cmd = new SqlCommand("SELECT COUNT(id) AS Expr1 FROM CellTable WHERE (name = @name)", m_connection);
            cmd.CommandTimeout = m_Timeout;
            cmd.Parameters.Add("@name", SqlDbType.NVarChar);
            cmd.Parameters[0].Value = cellName;
            //get result
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            SqlInt32 res = rdr.GetSqlInt32(0);
            rdr.Close();
            if (res.IsNull) return false;
            else return (bool)(res.Value != 0);
        }

        #endregion


        #region LinkSection table functions
        /// <summary>
        /// NT-Получить список связей, в соответствии с шаблоном поиска
        /// </summary>
        /// <param name="template">Шаблон поиска</param>
        /// <returns></returns>
        public MLinkCollection getLinks(MLinkTemplate tmp)
        {
            //SELECT LinkTable.* FROM LinkTable WHERE (downID = @Param1) AND (upID = @Param2) AND (axis = @Param3) AND (state = @Param4) AND (active = @Param5) AND (sflag = @Param6) AND (descr LIKE @Param7)
            StringBuilder sb = new StringBuilder();
            //create command, parameters and query
            bool AndFlag = false;//flag for AND word
            SqlParameter sp;

            //повторное использование команды не предполагается пока
            SqlCommand alias = new SqlCommand("", m_connection);
            //Создаем текст запроса и параметры
            sb.Append("SELECT LinkTable.* FROM LinkTable WHERE ");

            #region Creating query and parameters
            if (tmp.tableId.HasValue)
            {
                sb.Append("(id = @p1)");
                sp = new SqlParameter("@p1", SqlDbType.Int);
                sp.Value = tmp.tableId.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.downCellID != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(downID = @p2)");
                sp = new SqlParameter("@p2", SqlDbType.Int);
                sp.Value = tmp.downCellID.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.upCellID != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(upID = @p3)");
                sp = new SqlParameter("@p3", SqlDbType.Int);
                sp.Value = tmp.upCellID.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.Axis != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(axis = @p4)");
                sp = new SqlParameter("@p4", SqlDbType.Int);
                sp.Value = tmp.Axis.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.State != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(state = @p5)");
                sp = new SqlParameter("@p5", SqlDbType.Int);
                sp.Value = tmp.State.ID;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.isActive.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(active = @p6)");
                sp = new SqlParameter("@p6", SqlDbType.Bit);
                sp.Value = tmp.isActive.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.ServiceFlag.HasValue)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(sflag = @p7)");
                sp = new SqlParameter("@p7", SqlDbType.Int);
                sp.Value = tmp.ServiceFlag.Value;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            if (tmp.Description != null)
            {
                if (AndFlag == true) sb.Append(" AND ");
                sb.Append("(descr LIKE @p8)");
                sp = new SqlParameter("@p8", SqlDbType.NText);
                sp.Value = tmp.Description;
                alias.Parameters.Add(sp);
                AndFlag = true;
            }
            #endregion

            alias.CommandTimeout = m_Timeout; // *5 ?
            alias.CommandText = sb.ToString();
            //execute command
            SqlDataReader rdr = alias.ExecuteReader();
            //MLinkCollection col = new MLinkCollection();
            //MLink t;
            //if (rdr.HasRows)
            //{
            //    while (rdr.Read())
            //    {
            //        t = new MLink();
            //        t.tableId = rdr.GetInt32(0);
            //        t.downCellID = (uint)rdr.GetInt32(1);
            //        t.upCellID = (uint)rdr.GetInt32(2);
            //        t.Axis = (uint)rdr.GetInt32(3);
            //        t.State = (uint) rdr.GetInt32(4);
            //        t.isActive = rdr.GetBoolean(5);
            //        t.ServiceFlag = rdr.GetInt32(6);
            //        t.Description = rdr.GetString(7);

            //        col.AddLink(t);
            //    }
            //}
            //rdr.Close();

            return readLinkResultSet(rdr);
        }

        /// <summary>
        /// NT-Read all rows from sql result set, close reader.
        /// </summary>
        /// <param name="rdr"></param>
        /// <returns></returns>
        private MLinkCollection readLinkResultSet(SqlDataReader rdr)
        {
            MLinkCollection col = new MLinkCollection();
            MLink t;
            int tid;
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    t = new MLink();
                    tid = rdr.GetInt32(0); //вписывать в последнюю очередь, чтобы избежать записи в связь внутри. 
                    t.downCellID = new MID(rdr.GetInt32(1));
                    t.upCellID = new MID(rdr.GetInt32(2));
                    t.Axis = new MID(rdr.GetInt32(3));
                    t.State = new MID(rdr.GetInt32(4));
                    t.isActive = rdr.GetBoolean(5);
                    t.ServiceFlag = rdr.GetInt32(6);
                    t.Description = rdr.GetString(7);
                    t.TableId = tid;
                    col.AddLink(t);
                }
            }
            rdr.Close();
            return col;
        }

        /// <summary>
        /// NT-Get cell links filtered by axis direction
        /// </summary>
        /// <param name="cellid">cell id</param>
        /// <param name="axisDir">axis direction: Any, Up, Down</param>
        /// <returns></returns>
        public MLinkCollection getCellLinks(int cellid, MAxisDirection axisDir)
        {
            //SELECT LinkTable.* FROM LinkTable WHERE (downID = @cid) OR (upID = @cid)
            if (Cmd_getCellLinks == null)
            {
                Cmd_getCellLinks = new SqlCommand("", m_connection);
                Cmd_getCellLinks.CommandTimeout = m_Timeout;
                Cmd_getCellLinks.Parameters.Add("@cid", SqlDbType.Int);
            }
            Cmd_getCellLinks.Parameters[0].Value = cellid;
            //set query string
            switch (axisDir)
            {
                case MAxisDirection.Down:
                    Cmd_getCellLinks.CommandText = "SELECT LinkTable.* FROM LinkTable WHERE (upID = @cid)";
                    break;
                case MAxisDirection.Up:
                    Cmd_getCellLinks.CommandText = "SELECT LinkTable.* FROM LinkTable WHERE (downID = @cid)";
                    break;
                case MAxisDirection.Any:
                    Cmd_getCellLinks.CommandText = "SELECT LinkTable.* FROM LinkTable WHERE (downID = @cid) OR (upID = @cid)";
                    break;
                default:
                    throw new Exception("Invalid axis direction");
            }
            //execute command
            SqlDataReader rdr = Cmd_getCellLinks.ExecuteReader();
            return readLinkResultSet(rdr);
        }
        
        /// <summary>
        /// NT-insert LinkSection record into LinkTable
        /// </summary>
        /// <param name="link"></param>
        /// <returns>Num of affected rows</returns>
        internal int insertLink(MLink link)
        {
            string query = "INSERT INTO LinkTable (downID, upID, axis, state, active, sflag, descr, moditime) VALUES  (@down,@up,@axis,@state,@active,@sflag,@descr,@modit)";
            if (Cmd_insertLinkTable == null)
            {
                Cmd_insertLinkTable = new SqlCommand(query, m_connection);
                Cmd_insertLinkTable.CommandTimeout = m_Timeout;
                Cmd_insertLinkTable.Parameters.Add("@down", SqlDbType.Int);
                Cmd_insertLinkTable.Parameters.Add("@up", SqlDbType.Int);
                Cmd_insertLinkTable.Parameters.Add("@axis", SqlDbType.Int);
                Cmd_insertLinkTable.Parameters.Add("@state", SqlDbType.Int);
                Cmd_insertLinkTable.Parameters.Add("@active", SqlDbType.Bit);  
                Cmd_insertLinkTable.Parameters.Add("@sflag", SqlDbType.Int);              
                Cmd_insertLinkTable.Parameters.Add("@descr", SqlDbType.NText);
                Cmd_insertLinkTable.Parameters.Add("@modit", SqlDbType.DateTime);
            }
            //execute
            Cmd_insertLinkTable.Parameters[0].Value = link.downCellID.ID;
            Cmd_insertLinkTable.Parameters[1].Value = link.upCellID.ID;
            Cmd_insertLinkTable.Parameters[2].Value = link.Axis.ID;
            Cmd_insertLinkTable.Parameters[3].Value = link.State.ID;
            Cmd_insertLinkTable.Parameters[4].Value = link.isActive;
            Cmd_insertLinkTable.Parameters[5].Value = link.ServiceFlag;
            Cmd_insertLinkTable.Parameters[6].Value = link.Description;
            Cmd_insertLinkTable.Parameters[7].Value = DateTime.Now;
            //return num afected rows
            return Cmd_insertLinkTable.ExecuteNonQuery();

        }
        /// <summary>
        /// NT-Insert link to table and change and return link primary key, that serve as linkId.
        /// </summary>
        /// <param name="link"></param>
        /// <returns>Возвращает идентификатор связи</returns>
        public int insertLinkGetId(MLink link)
        {
            insertLink(link);
            //вернуть ид связи 
            int id = getLastIdentityLinksTable();
            link.TableId = id;
            return id;
        }
        /// <summary>
        /// NT-Delete link by link table id
        /// </summary>
        /// <param name="linkId">link id from table primary key</param>
        /// <returns></returns>
        internal int deleteLink(int linkId)
        {
            if (Cmd_deleteLinkById == null)
            {
                Cmd_deleteLinkById = new SqlCommand("DELETE FROM LinkTable WHERE (id = @lid)", m_connection);
                Cmd_deleteLinkById.CommandTimeout = m_Timeout;
                Cmd_deleteLinkById.Parameters.Add("@lid", SqlDbType.Int);

            }
            Cmd_deleteLinkById.Parameters[0].Value = linkId;
            return Cmd_deleteLinkById.ExecuteNonQuery();
        }

        /// <summary>
        /// NR-get link id primary key for first founded link. Return 0 if link not exists
        /// TODO: неправильно работает при наличии нескольких связей между ячейками
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        public int getLinkID(MID dnCellId, MID upCellId, MID axis)
        {
            //SELECT LinkTable.id FROM LinkTable WHERE (downID = @cidn) AND (upID = @cidu) AND (axis = @axis)
            if (Cmd_getLinkId == null)
            {
                Cmd_getLinkId = new SqlCommand("SELECT LinkTable.id FROM LinkTable WHERE (downID = @cidn) AND (upID = @cidu) AND (axis = @axis)", m_connection);
                Cmd_getLinkId.CommandTimeout = m_Timeout;
                Cmd_getLinkId.Parameters.Add("@cidn", SqlDbType.Int);
                Cmd_getLinkId.Parameters.Add("@cidu", SqlDbType.Int);
                Cmd_getLinkId.Parameters.Add("@axis", SqlDbType.Int);
            }
            Cmd_getLinkId.Parameters[0].Value = dnCellId.ID;
            Cmd_getLinkId.Parameters[1].Value = upCellId.ID;
            Cmd_getLinkId.Parameters[2].Value = axis.ID;
            SqlDataReader rdr = Cmd_getLinkId.ExecuteReader();
            int result = 0;
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }
        /// <summary>
        /// NR-get link id primary key for first founded link. Return 0 if link not exists
        /// TODO: неправильно работает при наличии нескольких связей между ячейками
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        public int getLinkID(MLink link)
        {
            return getLinkID(link.downCellID, link.upCellID, link.Axis);
        }

        /// <summary>
        /// NT-Return last LinkTable identity (primary key value)
        /// </summary>
        /// <returns></returns>
        internal int getLastIdentityLinksTable()
        {
            string query = "SELECT IDENT_CURRENT('LinkTable') AS Expr1";  //Поведение после отката транзакции неясно.

            if (Cmd_getLastLinksIdentity == null)
            {
                Cmd_getLastLinksIdentity = new SqlCommand(query, m_connection);
                Cmd_getLastLinksIdentity.CommandTimeout = m_Timeout;
                Cmd_getLastLinksIdentity.CommandType = CommandType.Text;  
             
                //Cmd_getLastLinksIdentity = new SqlCommand("SELECT IDENT_CURRENT( @tablename ) AS Expr1", m_connection);
                //Cmd_getLastLinksIdentity.CommandTimeout = m_Timeout;
                //Cmd_getLastLinksIdentity.CommandType = CommandType.Text;
                //Cmd_getLastLinksIdentity.Parameters.Add("@tablename", SqlDbType.VarChar);
                //Cmd_getLastLinksIdentity.Parameters[0].Value = "LinkTable";

                //Cmd_getLastLinksIdentity = new SqlCommand("dbo.GETLINKTABLEIDENTITY", m_connection);
                //Cmd_getLastLinksIdentity.CommandTimeout = m_Timeout;
                //Cmd_getLastLinksIdentity.CommandType = CommandType.StoredProcedure;
            }
            //Cmd_getLastLinksIdentity.Connection = new SqlConnection(m_ConnString);
            //Cmd_getLastLinksIdentity.Connection.Open();
            Object ob =  Cmd_getLastLinksIdentity.ExecuteScalar();
            int result = 0;
            if (ob != null) result = Convert.ToInt32(ob);
            //SqlDataReader rdr = Cmd_getLastLinksIdentity.ExecuteReader(CommandBehavior.CloseConnection);
            //int result = 0;
            //if (rdr.HasRows)
            //{
            //    rdr.Read();
            //    result = rdr.GetInt32(0);
            //}
            //rdr.Close();
            //Cmd_getLastLinksIdentity.Connection.Close();

            return (int) result;

        }


        /// <summary>
        /// Update link. Return num of affected rows
        /// </summary>
        /// <param name="link"></param>
        /// <returns></returns>
        internal int updateLink(MLink link)
        {
            
           
            string query = "UPDATE LinkTable SET downID = @down, upID = @up, axis = @axis, state = @state, active = @active, sflag = @sflag, descr = @descr, moditime = @modit WHERE (id = @lid)";
            if (Cmd_updateLinkTable == null)
            {
                Cmd_updateLinkTable = new SqlCommand(query, m_connection);
                Cmd_updateLinkTable.CommandTimeout = m_Timeout;
                Cmd_updateLinkTable.Parameters.Add("@down", SqlDbType.Int);
                Cmd_updateLinkTable.Parameters.Add("@up", SqlDbType.Int);
                Cmd_updateLinkTable.Parameters.Add("@axis", SqlDbType.Int);
                Cmd_updateLinkTable.Parameters.Add("@state", SqlDbType.Int);
                Cmd_updateLinkTable.Parameters.Add("@active", SqlDbType.Bit);
                Cmd_updateLinkTable.Parameters.Add("@sflag", SqlDbType.Int);
                Cmd_updateLinkTable.Parameters.Add("@descr", SqlDbType.NText);
                Cmd_updateLinkTable.Parameters.Add("@modit", SqlDbType.DateTime);
                Cmd_updateLinkTable.Parameters.Add("@lid", SqlDbType.Int);
            }
            //execute
            Cmd_updateLinkTable.Parameters[0].Value = link.downCellID.ID;
            Cmd_updateLinkTable.Parameters[1].Value = link.upCellID.ID;
            Cmd_updateLinkTable.Parameters[2].Value = link.Axis.ID;
            Cmd_updateLinkTable.Parameters[3].Value = link.State.ID;
            Cmd_updateLinkTable.Parameters[4].Value = link.isActive;
            Cmd_updateLinkTable.Parameters[5].Value = link.ServiceFlag;
            Cmd_updateLinkTable.Parameters[6].Value = link.Description;
            Cmd_updateLinkTable.Parameters[7].Value = DateTime.Now;
            Cmd_updateLinkTable.Parameters[8].Value = link.TableId;
            //return num afected rows
            return Cmd_updateLinkTable.ExecuteNonQuery();

        }

        /// <summary>
        /// NT-Get min of link primary key in table. Return 0 if no links.
        /// </summary>
        /// <returns></returns>
        internal int getMinLinkId()
        {
            SqlCommand cmd = new SqlCommand("SELECT MIN(id) AS Expr1 FROM LinkTable", m_connection);
            cmd.CommandTimeout = m_Timeout;
            //get result
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            SqlInt32 res = rdr.GetSqlInt32(0);
            rdr.Close();
            if (res.IsNull) return 0;
            else return res.Value;
        }
        /// <summary>
        /// NT-Get max of link primary key in table. Return 0 if no links.
        /// </summary>
        /// <returns></returns>
        internal int getMaxLinkId()
        {
            SqlCommand cmd = new SqlCommand("SELECT MAX(id) AS Expr1 FROM LinkTable", m_connection);
            cmd.CommandTimeout = m_Timeout;
            //get result
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            SqlInt32 res = rdr.GetSqlInt32(0);
            rdr.Close();
            if (res.IsNull) return 0;
            else return res.Value;
        }

        /// <summary>
        /// NT-Get band of links
        /// </summary>
        /// <param name="rowFrom">link id from which begin select links</param>
        /// <param name="rowTo">link id to (but not include) end select links</param>
        /// <returns></returns>
        internal MLinkCollection getBandOfLinkById(int rowFrom, int rowTo)
        {
            if (Cmd_getBandLink == null)
            {
                Cmd_getBandLink = new SqlCommand("SELECT LinkTable.* FROM LinkTable WHERE ((id >= @idfrom) AND (id < @idto))", m_connection);
                Cmd_getBandLink.CommandTimeout = m_Timeout;
                Cmd_getBandLink.Parameters.Add("@idfrom", SqlDbType.Int);
                Cmd_getBandLink.Parameters.Add("@idto", SqlDbType.Int);
            }
            //execute
            Cmd_getBandLink.Parameters[0].Value = rowFrom;
            Cmd_getBandLink.Parameters[1].Value = rowTo;
            SqlDataReader rdr = Cmd_getBandLink.ExecuteReader();

            return readLinkResultSet(rdr);
        }

        #endregion








        /// <summary>
        /// NR-Return number of rows in link table
        /// </summary>
        /// <returns></returns>
        internal int getNumberOfLinks()
        {
            SqlCommand cmd = new SqlCommand("SELECT COUNT(id) AS Expr1 FROM LinkTable", m_connection);
            cmd.CommandTimeout = m_Timeout;
            //get result
            SqlDataReader rdr = cmd.ExecuteReader();
            rdr.Read();
            SqlInt32 res = rdr.GetSqlInt32(0);
            rdr.Close();
            if (res.IsNull) return 0;
            else return res.Value; ;
        }





    }
}
