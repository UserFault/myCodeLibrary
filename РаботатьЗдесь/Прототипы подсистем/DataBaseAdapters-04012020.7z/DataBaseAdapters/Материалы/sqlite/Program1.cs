﻿using System;
using System.Collections.Generic;
using System.Text;
using MySqliteDbLayer;
using System.Data.SQLite;

namespace FindSeqNextAssembler
{
    class Program
    {
        /// <summary>
        /// Массив баз данных
        /// </summary>        
        static MySqliteDbLayer.SqliteDbAdapter[] m_databases;
        static SQLiteTransaction[] m_transactions;
        /// <summary>
        /// номер шага как число полей кода слова
        /// </summary>
        static int m_stepnumber;

        static void Main(string[] args)
        {
            Console.WriteLine("Сборка всех библиотек в одну");
            Console.WriteLine("Program stepnum db0 db1 db2 db3 db4 db5 db6...");
            
            //тут берем первую бд и вторую бд.
            //из первой БД читаем строку и ищем ее во второй бд
            //если она там есть, обновляем значение в первой бд
            //а из второй БД строку удаляем по ее идентификатору
            //потом так же с третьей БД, четвертой итд.
            //в результате после прохода первой БД остальные БД уменьшаются, содержат только элементы, которых нет в первой БД.
            //потом так же проходим вторую БД, третью итд.
            //потом во всех БД надо удалить единичные строки.
            //потом собрать все БД в одну.
            //польза в том, что БД не раздувается, собирая все данные,
            //ее проще обрабатывать, так как в ней меньше записей.
            //проблема в том что в прогу надо завести все БД сразу. Как их через параметры передать?  
            try
            {
                m_stepnumber = Int32.Parse(args[0]);
                //общее количество БД в аргументах
                int dbcount = args.Length - 1;
                m_databases = new SqliteDbAdapter[dbcount];
                m_transactions = new SQLiteTransaction[dbcount];
                for (int i = 0; i < dbcount; i++)
                {
                    m_databases[i] = new SqliteDbAdapter(SqliteDbAdapter.CreateConnection(args[i + 1]));
                }


                //проходим исходные БД
                for (int dbnum = 0; dbnum < dbcount - 1; dbnum++)
                {
                    //открыть тут основную бд и выделить ей большой кеш и начать транзакцию
                    //тут открыть последующие БД и назначить им кеш и начать транзакции
                    //тут принять транзакции и закрыть все БД
                    int cachepages = 200000 / dbcount - dbnum; //300мб кэша на все БД
                    string cachestr = String.Format("PRAGMA cache_size = {0};", cachepages);
                    for (int i = dbnum; i < dbcount; i++)
                    {
                        m_databases[i].Open();
                        m_databases[i].ExecuteCommand(cachestr);
                        m_transactions[i] = m_databases[i].BeginTransaction();
                    }
                    m_databases[dbnum].ExecuteCommand("PRAGMA cache_size = 150000;");
                    
                    //process databases
                    Console.WriteLine("Process database " + dbnum.ToString());
                    Console.Write("0");
                    MySqliteDbLayer.SqliteDbAdapter dbsrc = m_databases[dbnum];
                    //get min rowid
                    Int32 minId = dbsrc.seqGetMinRowId();
                    //get max rowid
                    Int32 maxId = dbsrc.seqGetMaxRowId();

                    List<Seq2Item> items;
                    //get each row in rows                   
                    for (int i = minId; i <= maxId; i += 4096)
                    {
                        //тут прочитать одну строку из бд по dbnum
                        items = dbsrc.seqGetRows(m_stepnumber, i, i + 4096);
                        foreach (Seq2Item item in items)
                        {
                            uint wordcount = 0;
                            //проходим конечные БД
                            for (int dbindex = dbnum + 1; dbindex < dbcount; dbindex++)
                            {

                                //тут запросить все такие строки из каждой бд dbindex
                                Seq2Item it = m_databases[dbindex].seqGetRow(m_stepnumber, item.m_codes);
                                if (it != null)
                                {
                                    //и суммировать их счетчики
                                    wordcount += (uint) it.m_count;
                                    //а сами строки удалить
                                    m_databases[dbindex].seqDeleteById(it.m_id);
                                }
                            }
                            //тут добавить значение счетчика в бд по dbnum
                            if(wordcount > 0)
                                dbsrc.Seq2Update(item.m_id, wordcount);
                            //вывести пользователю счетчик выполнения
                            if ((item.m_id & 0xFF) == 0)
                            {
                                Console.CursorLeft = 0; //вернуть курсор на начало строки
                                Console.Write(item.m_id);
                            }
                        }
                    }

                    //тут принять транзакции и закрыть все БД
                    for (int i = dbnum; i < m_databases.Length; i++)
                    {
                        m_transactions[i].Commit();
                        m_databases[i].Close();
                    }
                }
                //Commit transactions
                //foreach (SQLiteTransaction t in m_transactions)
                //    t.Commit();

                //тут собрать все БД в одну, исключая единичные записи.
                for (int dbn = 1; dbn < dbcount; dbn++)
                {
                    //AppendDatabase(args[0], args[dbn]);
                }

                ////Commit transactions
                //for (int i = 0; i < m_databases.Length; i++)
                //{
                //    m_transactions[i].Commit();
                //    m_databases[i].Close();
                //}
            }
            catch (Exception ex)
            {
                //Rollback transactions
                for (int i = 0; i < m_databases.Length; i++)
                {
                    m_transactions[i].Rollback();
                    m_databases[i].Close();
                }
                Console.WriteLine(ex.GetType().ToString() + ex.Message);
            }
            //Console.ReadLine();
            return;
        }

        private static void AppendDatabase(string p, string p_2)
        {
            throw new NotImplementedException();
        }

        private static void ProcessDatabasePair(string src, string dst)
        {
            Console.WriteLine(src + " - " + dst);
        }
    }
}
