﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SQLite;


namespace MySqliteDbLayer
{
    public class SqliteDbAdapter
    {
        public SQLiteConnection m_connection;
        /// <summary>
        /// getIdBySymbol command
        /// </summary>
        private SQLiteCommand m_cmd1;
        /// <summary>
        /// getSymbolById command
        /// </summary>
        private SQLiteCommand m_cmd2;
        /// <summary>
        /// addSymbol command
        /// </summary>
        private SQLiteCommand m_cmd3;
        /// <summary>
        /// incrementSymbolCount command
        /// </summary>
        private SQLiteCommand m_cmd4;
        /// <summary>
        ///  getSymbols command
        /// </summary>
        private SQLiteCommand m_cmd5;

        private SQLiteCommand m_cmdS1;
        private SQLiteCommand m_cmdS2;
        private SQLiteCommand m_cmdS3;

        private SQLiteCommand m_seqCmdGetId;
        private SQLiteCommand m_seqCmdInsert;
        private SQLiteCommand m_seqCmdGetRows;
        private SQLiteCommand m_seqCmdDelete;
        private SQLiteCommand m_seqCmdGetRow;

        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="con">Объект соединения с БД</param>
        public SqliteDbAdapter(SQLiteConnection con)
        {
            this.m_connection = con;
        }

        /// <summary>
        /// NT-Открыть соединение с БД
        /// </summary>
        public void Open()
        {
            m_connection.Open();
        }
        /// <summary>
        /// NT-Закрыть соединение с БД
        /// </summary>
        public void Close()
        {
            if (m_connection == null) return;
            if (m_connection.State == System.Data.ConnectionState.Open)
            {
                m_connection.Close();
            }

            return;
        }

        /// <summary>
        /// NT- Создать новый пустой файл для базы данных
        /// </summary>
        /// <param name="filename">Путь к файлу БД</param>
        public static void CreateDatabase(string filename)
        {
            SQLiteConnection.CreateFile(filename);
            return;
        }

        /// <summary>
        /// NT-Создать объект соединения с БД
        /// </summary>
        /// <param name="filename">Путь к файлу БД</param>
        /// <returns></returns>
        public static SQLiteConnection CreateConnection(string filename)
        {
            SQLiteConnectionStringBuilder builder = new SQLiteConnectionStringBuilder();
            //open dummy file
            builder.DataSource = filename;
            String constring = builder.ConnectionString;
            //open connection
            SQLiteConnection myconnection = new SQLiteConnection(constring);
            return myconnection;
        }

        /// <summary>
        /// NT-начать транзакцию - это сильно ускоряет массовые операции записи.
        /// После завершения операции транзакцию необходимо подтвердить или отменить.
        /// </summary>
        /// <returns>Объект транзакции.</returns>
        public SQLiteTransaction BeginTransaction()
        {
            return this.m_connection.BeginTransaction();
        }
        #region *** Symbol database tables ***
        /// <summary>
        /// NT-Создать в новой БД таблицу для символов
        /// </summary>
        /// <returns></returns>
        public bool CreateSymbolTable()
        {
            using (SQLiteTransaction mytransaction = m_connection.BeginTransaction())
            {
                using (SQLiteCommand mycommand = new SQLiteCommand(m_connection))
                {
                    mycommand.CommandText = "CREATE TABLE \"sym\"(\"id\" Integer Primary Key Autoincrement, \"txt\" Text, \"cnt\" Integer DEFAULT(0))";
                    mycommand.ExecuteNonQuery();
                    //index
                    mycommand.CommandText = "CREATE UNIQUE INDEX ind_txt ON sym(txt ASC);";
                    mycommand.ExecuteNonQuery();

                    mycommand.CommandText = "CREATE UNIQUE INDEX ind_id ON sym(id ASC);";
                    mycommand.ExecuteNonQuery();
                }
                mytransaction.Commit();
            }
            return true;
        }

        /// <summary>
        /// NT-запрос есть ли в таблице строка такого текста
        /// </summary>
        /// <param name="text">строка текста</param>
        /// <returns>идентификатор строки таблицы или 0 если строки нет</returns>
        public Int32 getIdBySymbol(string text)
        {
            Int32 result = 0;
            //create command
            if (this.m_cmd1 == null)
            {
                this.m_cmd1 = new SQLiteCommand(m_connection);
                this.m_cmd1.CommandText = "SELECT \"id\" FROM \"sym\" WHERE (\"txt\"=?);";
                this.m_cmd1.CommandTimeout = 600;
                //parameters
                this.m_cmd1.Parameters.Add("p0", System.Data.DbType.String);
            }
            //read one result
            this.m_cmd1.Parameters[0].Value = text;
            SQLiteDataReader rdr = this.m_cmd1.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }

        //запрос добавления текста в таблицу
        //аргументы: строка текста
        //возвращает: ничего
        public void addSymbol(string text)
        {
            //SQLiteTransaction mytransaction = this.m_connection.BeginTransaction();

            //create command
            if (this.m_cmd3 == null)
            {
                this.m_cmd3 = new SQLiteCommand(m_connection);
                this.m_cmd3.CommandText = "INSERT INTO \"sym\"(\"txt\", \"cnt\") VALUES (?, 1);";
                this.m_cmd3.CommandTimeout = 600;
                //parameters
                this.m_cmd3.Parameters.Add("p0", System.Data.DbType.String);
            }
            //insert one result
            this.m_cmd3.Parameters[0].Value = text;
            this.m_cmd3.ExecuteNonQuery();

            //mytransaction.Commit();

            return;
        }

        /// <summary>
        /// NT-запрос получения текста из таблицы по идентификатору
        /// </summary>
        /// <param name="id">идентификатор строки</param>
        /// <returns>строка текста или нуль</returns>
        public string getSymbolById(Int32 id)
        {
            String result = null;
            //create command
            if (this.m_cmd2 == null)
            {
                this.m_cmd2 = new SQLiteCommand(m_connection);
                this.m_cmd2.CommandText = "SELECT \"txt\" FROM \"sym\" WHERE (\"id\"=?);";
                this.m_cmd2.CommandTimeout = 600;
                //parameters
                this.m_cmd2.Parameters.Add("p0", System.Data.DbType.Int32);
            }
            //read one result
            this.m_cmd2.Parameters[0].Value = id;
            SQLiteDataReader rdr = this.m_cmd2.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetString(0);
            }
            rdr.Close();
            return result;
        }

        //запрос инкремента счетчика строки таблицы
        //аргументы: 
        public void incrementSymbolCount(int id)
        {
            //create command
            if (this.m_cmd4 == null)
            {
                this.m_cmd4 = new SQLiteCommand(m_connection);
                this.m_cmd4.CommandText = "UPDATE \"sym\" SET \"cnt\"=\"cnt\" + 1 WHERE(\"id\"=?);";
                this.m_cmd4.CommandTimeout = 600;
                //parameters
                this.m_cmd4.Parameters.Add("p0", System.Data.DbType.Int32);
            }
            //insert one result
            this.m_cmd4.Parameters[0].Value = id;
            this.m_cmd4.ExecuteNonQuery();

            return;
        }
        /// <summary>
        /// NT-Получить минимальный ИД таблицы
        /// </summary>
        /// <returns></returns>
        public Int32 getSymbolsMinId()
        {
            Int32 result = 0;
            //create command
            SQLiteCommand cmd = new SQLiteCommand(m_connection);
            cmd.CommandText = "SELECT MIN(\"id\") FROM \"sym\";";
            cmd.CommandTimeout = 600;

            //read one result
            SQLiteDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }

        /// <summary>
        /// NT-Получить максимальный ИД таблицы
        /// </summary>
        /// <returns></returns>
        public Int32 getSymbolsMaxId()
        {
            Int32 result = 0;
            //create command
            SQLiteCommand cmd = new SQLiteCommand(m_connection);
            cmd.CommandText = "SELECT MAX(\"id\") FROM \"sym\";";
            cmd.CommandTimeout = 600;

            //read one result
            SQLiteDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }

        /// <summary>
        /// NT-запрос получения лексем из таблицы по идентификатору
        /// </summary>
        /// <param name="idFrom">Идентификатор первого элемента</param>
        /// <param name="count">Количество элементов</param>
        /// <returns>Список объектов строк таблицы</returns>
        public List<TableDictItem> getSymbols(Int32 idFrom, Int32 count)
        {
            List<TableDictItem> result = new List<TableDictItem>(count);
            Int32 idTo = idFrom + count;
            //create command
            if (this.m_cmd5 == null)
            {
                this.m_cmd5 = new SQLiteCommand(m_connection);
                this.m_cmd5.CommandText = "SELECT * FROM \"sym\" WHERE ((\"id\">=?) AND (\"id\"<?));";
                this.m_cmd5.CommandTimeout = 600;
                //parameters
                this.m_cmd5.Parameters.Add("p0", System.Data.DbType.Int32);
                this.m_cmd5.Parameters.Add("p1", System.Data.DbType.Int32);
            }
            //read one result
            this.m_cmd5.Parameters[0].Value = idFrom;
            this.m_cmd5.Parameters[1].Value = idFrom + count;
            SQLiteDataReader rdr = this.m_cmd5.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    TableDictItem td = new TableDictItem();
                    td.m_id = rdr.GetInt32(0);
                    td.m_text = rdr.GetString(1);
                    td.m_count = rdr.GetInt32(2);
                    result.Add(td);
                }
            }
            rdr.Close();
            return result;
        }
        #endregion

        #region *** Функции проекта сборки последовательностей ***

        /// <summary>
        /// NT-Создать в новой БД таблицу для переработки последовательностей
        /// </summary>
        /// <returns></returns>
        public bool CreateSequenceTable()
        {
            using (SQLiteTransaction mytransaction = m_connection.BeginTransaction())
            {
                using (SQLiteCommand mycommand = new SQLiteCommand(m_connection))
                {
                    mycommand.CommandText = "DROP TABLE IF EXISTS `seq2`;";
                    mycommand.ExecuteNonQuery();
                    mycommand.CommandText = "CREATE TABLE \"seq2\"(\"code0\" Integer  NOT NULL DEFAULT (0), \"code1\" Integer NOT NULL DEFAULT (0), \"count\" Integer NOT NULL DEFAULT (0));";
                    mycommand.ExecuteNonQuery();
                    //index
                    mycommand.CommandText = "CREATE UNIQUE INDEX ind_c0c1 ON seq2(code0 ASC, code1 ASC);";
                    mycommand.ExecuteNonQuery();

                    //mycommand.CommandText = "CREATE INDEX ind_c1 ON seq2(code1 ASC);";
                    //mycommand.ExecuteNonQuery();
                }
                mytransaction.Commit();
            }
            return true;
        }
        public void AddSequence(uint c0, uint c1, uint cnt)
        {
            //тут надо или увеличить значение счетчика в таблице или создать новую запись.
            Int64 id = Seq2GetRecordId(c0, c1);
            //если записи нет, то применяется INSERT
            //если запись есть, применяется UPDATE
            if (id == -1)
                Seq2Insert(c0, c1, cnt);
            else
                Seq2Update(id, cnt);
        }
        /// <summary>
        /// NT-функция обновляет строку по ее ROWID. Пригодна для всех шагов словосочетаний.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="cnt"></param>
        public void Seq2Update(long id, uint cnt)
        {
            //create command
            if (this.m_cmdS3 == null)
            {
                this.m_cmdS3 = new SQLiteCommand(m_connection);
                this.m_cmdS3.CommandText = "UPDATE \"seq2\" SET \"count\"=\"count\" + ? WHERE(\"ROWID\"=?);";
                this.m_cmdS3.CommandTimeout = 600;
                //parameters
                this.m_cmdS3.Parameters.Add("p0", System.Data.DbType.UInt32);
                this.m_cmdS3.Parameters.Add("p1", System.Data.DbType.Int64);
            }
            //insert one result
            this.m_cmdS3.Parameters[0].Value = cnt;
            this.m_cmdS3.Parameters[1].Value = id;
            this.m_cmdS3.ExecuteNonQuery();

            return;
        }
        /// <summary>
        /// NT- insert row
        /// </summary>
        /// <param name="c0"></param>
        /// <param name="c1"></param>
        /// <param name="cnt"></param>
        private void Seq2Insert(uint c0, uint c1, uint cnt)
        {
            //create command
            if (this.m_cmdS2 == null)
            {
                this.m_cmdS2 = new SQLiteCommand(m_connection);
                this.m_cmdS2.CommandText = "INSERT INTO \"seq2\"(\"code0\", \"code1\", \"count\") VALUES (?, ?, ?);";
                this.m_cmdS2.CommandTimeout = 600;
                //parameters
                this.m_cmdS2.Parameters.Add("p0", System.Data.DbType.UInt32);
                this.m_cmdS2.Parameters.Add("p1", System.Data.DbType.UInt32);
                this.m_cmdS2.Parameters.Add("p2", System.Data.DbType.UInt32);
            }
            //insert one result
            this.m_cmdS2.Parameters[0].Value = c0;
            this.m_cmdS2.Parameters[1].Value = c1;
            this.m_cmdS2.Parameters[2].Value = cnt;
            this.m_cmdS2.ExecuteNonQuery();

            return;
        }

        /// <summary>
        /// NT-
        /// </summary>
        /// <param name="c0"></param>
        /// <param name="c1"></param>
        /// <returns></returns>
        private long Seq2GetRecordId(uint c0, uint c1)
        {
            Int64 result = -1;
            //create command
            if (this.m_cmdS1 == null)
            {
                this.m_cmdS1 = new SQLiteCommand(m_connection);
                this.m_cmdS1.CommandText = "SELECT \"ROWID\" FROM \"seq2\" WHERE ((\"code0\"=?) AND (\"code1\"=?));";
                this.m_cmdS1.CommandTimeout = 600;
                //parameters
                this.m_cmdS1.Parameters.Add("p0", System.Data.DbType.UInt32);
                this.m_cmdS1.Parameters.Add("p1", System.Data.DbType.UInt32);
            }
            //read one result
            this.m_cmdS1.Parameters[0].Value = c0;
            this.m_cmdS1.Parameters[1].Value = c1;
            SQLiteDataReader rdr = this.m_cmdS1.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = (Int64)rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }

        #endregion
        /// <summary>
        /// NR-добавить запись в БД
        /// </summary>
        /// <param name="c0"></param>
        /// <param name="c1"></param>
        /// <param name="cnt"></param>

        /// <summary>
        /// NT-Выполнить оператор, заданный строкой текста
        /// </summary>
        /// <param name="cmdtext">Строка текста команды</param>
        public void ExecuteCommand(String cmdtext)
        {
            SQLiteCommand cmd = new SQLiteCommand(m_connection);
            cmd.CommandText = cmdtext;
            cmd.CommandTimeout = 6000;
            cmd.ExecuteNonQuery();
            return;
        }

        #region ***Универсальные функции процесса поиска последовательностей от 3 до 20 ***
        /// <summary>
        /// NT-получить словарь кодов первых символов из БД
        /// </summary>
        /// <returns></returns>
        public Dictionary<int, int> seqGetCode0Dictionary()
        {
            Dictionary<int, int> result = new Dictionary<int, int>();

            //get min rowid
            Int32 minId = seqGetMinRowId();
            //get max rowid
            Int32 maxId = seqGetMaxRowId();
            //get each row in rows 
            SQLiteCommand cmd = new SQLiteCommand(m_connection);
            cmd.CommandText = "SELECT code0 FROM seq2 WHERE((ROWID >= ?) AND (ROWID < ?));";
            cmd.CommandTimeout = 600;
            cmd.Parameters.Add("p0", System.Data.DbType.Int32);
            cmd.Parameters.Add("p1", System.Data.DbType.Int32);
            //read loop
            for (int i = minId; i <= maxId; i += 4096)
            {
                cmd.Parameters[0].Value = i;
                cmd.Parameters[1].Value = i + 4096;
                SQLiteDataReader rdr = cmd.ExecuteReader();
                if (rdr.HasRows)
                {

                    while (rdr.Read())
                    {
                        Int32 c0 = rdr.GetInt32(0);//TODO: getUInt32() не найдена
                        if (!result.ContainsKey(c0))
                            result.Add(c0, 0);
                    }
                }
                rdr.Close();
            }
            //return dictionary
            return result;
        }

        /// <summary>
        /// NT-получить максимальное значение ROWID
        /// </summary>
        /// <returns></returns>
        public Int32 seqGetMaxRowId()
        {
            Int32 result = -1;
            //create command
            SQLiteCommand cmd = new SQLiteCommand(m_connection);
            cmd.CommandText = "SELECT MAX(\"ROWID\") FROM \"seq2\";";
            cmd.CommandTimeout = 600;

            //read one result
            SQLiteDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }

        /// <summary>
        /// NT-получить минимальное значение ROWID
        /// </summary>
        /// <returns></returns>
        public int seqGetMinRowId()
        {
            Int32 result = -1;
            //create command
            SQLiteCommand cmd = new SQLiteCommand(m_connection);
            cmd.CommandText = "SELECT MIN(\"ROWID\") FROM \"seq2\";";
            cmd.CommandTimeout = 600;

            //read one result
            SQLiteDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt32(0);
            }
            rdr.Close();
            return result;
        }

        /// <summary>
        /// NT-Создать в новой БД таблицу для переработки последовательностей
        /// </summary>
        /// <param name="stepnumber">число столбцов кодов слов</param>
        /// <returns></returns>
        public bool seqCreateSequenceTable(int stepnumber)
        {
            using (SQLiteTransaction mytransaction = m_connection.BeginTransaction())
            {
                using (SQLiteCommand mycommand = new SQLiteCommand(m_connection))
                {
                    mycommand.CommandText = "DROP TABLE IF EXISTS \"seq2\";";
                    mycommand.ExecuteNonQuery();
                    //create new table
                    StringBuilder sb = new StringBuilder();
                    sb.Append("CREATE TABLE \"seq2\"(");
                    for (int i = 0; i < stepnumber; i++)
                    {
                        sb.Append("\"code");
                        sb.Append(i);
                        sb.Append("\" Integer  NOT NULL DEFAULT (0), ");
                    }
                    sb.Append("\"count\" Integer NOT NULL DEFAULT (0));");

                    mycommand.CommandText = sb.ToString();
                    mycommand.ExecuteNonQuery();
                    //index
                    sb.Length = 0;
                    sb.Append("CREATE UNIQUE INDEX ind_c ON \"seq2\"(");
                    for (int i = 0; i < stepnumber; i++)
                    {
                        sb.Append("\"code");
                        sb.Append(i);
                        sb.Append("\" ASC, ");
                    }
                    sb.Remove(sb.Length - 2, 2); //remove last ,
                    sb.Append(");");
                    mycommand.CommandText = sb.ToString();  //"CREATE INDEX ind_c0c1 ON seq2(code0 ASC, code1 ASC);";
                    mycommand.ExecuteNonQuery();

                }
                mytransaction.Commit();
            }
            return true;
        }
        /// <summary>
        /// NT-добавить запись в БД
        /// </summary>
        /// <param name="codes">массив кодов значений</param>
        /// <param name="cnt">значение для счетчика</param>
        public void seqAddSequence(Int32[] codes, int cnt)
        {
            //тут надо или увеличить значение счетчика в таблице или создать новую запись.
            Int64 id = seqGetRecordId(codes);
            //если записи нет, то применяется INSERT
            //если запись есть, применяется UPDATE
            if (id == -1)
                seqInsert(codes, cnt);
            else
                Seq2Update(id, (UInt32)cnt);
            return;
        }


        /// <summary>
        /// NT-получить идентификатор строки таблицы по кодам в столбцах, -1 если не найдено.
        /// </summary>
        /// <param name="codes"></param>
        /// <returns></returns>
        private long seqGetRecordId(int[] codes)
        {
            //create command
            if (m_seqCmdGetId == null)
            {
                m_seqCmdGetId = new SQLiteCommand(m_connection);
                m_seqCmdGetId.CommandTimeout = 600;

                //create command string
                //SELECT ROWID FROM seq2 WHERE ((code0=?) AND (code1=?) AND (code2=?));
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT ROWID FROM seq2 WHERE( ");
                for (int i = 0; i < codes.Length; i++)
                {
                    sb.Append("(\"code");
                    sb.Append(i);
                    sb.Append("\" = ?) AND ");
                    //заодно создаем параметры
                    m_seqCmdGetId.Parameters.Add(String.Format("p{0}", i), System.Data.DbType.Int32);
                }
                sb.Append("(1 = 1));");//завершение запроса

                m_seqCmdGetId.CommandText = sb.ToString();
            }
            //execute command
            Int64 result = -1;
            //read one result
            //fill parameters
            for (int ii = 0; ii < codes.Length; ii++)
            {
                this.m_seqCmdGetId.Parameters[ii].Value = codes[ii];
            }
            //execute
            SQLiteDataReader rdr = this.m_seqCmdGetId.ExecuteReader();
            if (rdr.HasRows)
            {
                rdr.Read();
                result = rdr.GetInt64(0);
            }
            rdr.Close();
            return result;

        }
        /// <summary>
        /// NT-вставить новую запись в таблицу
        /// </summary>
        /// <param name="codes"></param>
        /// <param name="cnt"></param>
        private void seqInsert(int[] codes, int cnt)
        {
            //create command
            if (m_seqCmdInsert == null)
            {
                m_seqCmdInsert = new SQLiteCommand(m_connection);
                m_seqCmdInsert.CommandTimeout = 6000;

                //create command string
                //INSERT INTO \"seq2\" (\"code0\", \"code1\", \"count\") VALUES (?, ?, ?); ;
                StringBuilder sb = new StringBuilder();
                sb.Append("INSERT INTO \"seq2\" ( ");
                for (int i = 0; i < codes.Length; i++)
                {
                    sb.Append("\"code");
                    sb.Append(i);
                    sb.Append("\", ");
                    //заодно создаем параметры
                    m_seqCmdInsert.Parameters.Add(String.Format("p{0}", i), System.Data.DbType.Int32);
                }
                sb.Append("\"count\") VALUES (");
                for (int ii = 0; ii < codes.Length; ii++)
                {
                    sb.Append("?, ");
                }
                sb.Append("? );"); //end
                m_seqCmdInsert.CommandText = sb.ToString();
                //add last parameter for count column
                m_seqCmdInsert.Parameters.Add("cnt", System.Data.DbType.Int32);
            }
            //execute command
            //fill parameters
            for (int iii = 0; iii < codes.Length; iii++)
            {
                this.m_seqCmdInsert.Parameters[iii].Value = codes[iii];
            }
            //set counter parameter
            this.m_seqCmdInsert.Parameters[codes.Length].Value = cnt;

            //execute command
            m_seqCmdInsert.ExecuteNonQuery();

            return;
        }


        /// <summary>
        /// NR- проверить, что в таблице есть строка с такими кодами
        /// </summary>
        /// <param name="codes">список кодов для столбцов поиска</param>
        /// <param name="num">количество проверяемых столбцов</param>
        public bool seqCheckRecordExists(List<int> codes, int num)
        {
            //создаем временный массив кодов для передачи в функцию
            int[] tmp = new Int32[num];
            for (int i = 0; i < num; i++)
                tmp[i] = codes[i];

            Int64 id = seqGetRecordId(tmp);
            if (id == -1) return false;
            else return true;
        }

        #endregion



        /// <summary>
        /// NR-получить список строк в интервале от start до stop
        /// </summary>
        /// <param name="stepnum">Уровень БД как число полей кодов слов</param>
        /// <param name="start"></param>
        /// <param name="stor"></param>
        /// <returns></returns>
        public List<Seq2Item> seqGetRows(int stepnum, int start, int stop)
        {
            
            //get each row in rows 
            if(m_seqCmdGetRows == null)
            {
                m_seqCmdGetRows = new SQLiteCommand(m_connection);
                //make command text
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT \"ROWID\", ");
                for (int i = 0; i < stepnum; i++)
                {
                    sb.Append("\"code");
                    sb.Append(i);
                    sb.Append("\", ");
                }
                sb.Append("\"count\" FROM \"seq2\" WHERE((ROWID >= ?) AND (ROWID < ?));");
                m_seqCmdGetRows.CommandText = sb.ToString();
                m_seqCmdGetRows.CommandTimeout = 600;
                m_seqCmdGetRows.Parameters.Add("p0", System.Data.DbType.Int32);
                m_seqCmdGetRows.Parameters.Add("p1", System.Data.DbType.Int32);
            }

            List<Seq2Item> items = new List<Seq2Item>();
            //execute 
                m_seqCmdGetRows.Parameters[0].Value = start;
                m_seqCmdGetRows.Parameters[1].Value = stop;
                SQLiteDataReader rdr = m_seqCmdGetRows.ExecuteReader();
                if (rdr.HasRows)
                {
                    while (rdr.Read())
                    {
                        Seq2Item item = new Seq2Item();
                        item.m_codes = new Int32[stepnum];
                        item.m_id = rdr.GetInt64(0);
                        for (int i = 0; i < stepnum; i++)
                            item.m_codes[i] = rdr.GetInt32(i + 1);
                        item.m_count = rdr.GetInt32(stepnum + 1);
                        items.Add(item);
                    }
                }
                rdr.Close();
                return items;
        }

        
        
        /// <summary>
        /// NT-получить одну строку по кодам слов. Вернуть null если не найдено.
        /// </summary>
        /// <param name="stepnum"></param>
        /// <param name="codes"></param>
        /// <returns></returns>
        public Seq2Item seqGetRow(int stepnum, int[] codes)
        {

            //create command
            if (m_seqCmdGetRow == null)
            {
                m_seqCmdGetRow = new SQLiteCommand(m_connection);
                m_seqCmdGetRow.CommandTimeout = 600;

                //create command string
                //SELECT ROWID FROM seq2 WHERE ((code0=?) AND (code1=?) AND (code2=?));
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT \"ROWID\", \"count\" FROM \"seq2\" WHERE( ");
                for (int i = 0; i < codes.Length; i++)
                {
                    sb.Append("(\"code");
                    sb.Append(i);
                    sb.Append("\" = ?) AND ");
                    //заодно создаем параметры
                    m_seqCmdGetRow.Parameters.Add(String.Format("p{0}", i), System.Data.DbType.Int32);
                }
                sb.Append("(1 = 1));");//завершение запроса

                m_seqCmdGetRow.CommandText = sb.ToString();
            }
            //execute command
            //read one result
            //fill parameters
            for (int ii = 0; ii < codes.Length; ii++)
            {
                this.m_seqCmdGetRow.Parameters[ii].Value = codes[ii];
            }
            //execute
            SQLiteDataReader rdr = this.m_seqCmdGetRow.ExecuteReader();
            Seq2Item result = null;
            if (rdr.HasRows)
            {
                rdr.Read();
                result = new Seq2Item();
                result.m_id = rdr.GetInt64(0);//TODO: проверить
                result.m_codes = codes;
                result.m_count = rdr.GetInt32(1);
            }
            rdr.Close();
            return result;
        }
        ///// <summary>
        ///// NR-Обновить счетчик словосочетания
        ///// </summary>
        ///// <param name="m_stepnumber"></param>
        ///// <param name="item"></param>
        //public void seq2ItemUpdate(Seq2Item item)
        //{
        //    throw new NotImplementedException();
        //}



        /// <summary>
        /// NT-удалить запись из таблицы по ее ROWID
        /// </summary>
        /// <param name="id"></param>
        public void seqDeleteById(long id)
        {
            //create command
            if (this.m_seqCmdDelete == null)
            {
                this.m_seqCmdDelete = new SQLiteCommand(m_connection);
                this.m_seqCmdDelete.CommandText = "DELETE FROM \"seq2\" WHERE(\"ROWID\"=?);";
                this.m_seqCmdDelete.CommandTimeout = 6000;
                //parameters
                this.m_seqCmdDelete.Parameters.Add("p0", System.Data.DbType.Int64);
            }
            //insert one result
            this.m_seqCmdDelete.Parameters[0].Value = id;
            this.m_seqCmdDelete.ExecuteNonQuery();

            return;
        }
    }//end class
}
