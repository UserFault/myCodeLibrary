﻿using System.Threading;
using MyCodeLibrary;
using MyCodeLibrary.FileOperations;
using System;

namespace ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            ////test for windows
            //CWindowProcessor.СвернутьВсеОкна();
            //Thread.Sleep(5000);
            //CWindowProcessor.РазвернутьВсеОкна();
            //Thread.Sleep(5000);
            ////make screenshot
            //System.Drawing.Bitmap b = CImageProcessor.GetScreenShot(System.Windows.Forms.Screen.PrimaryScreen);
            //b.Save(@"c:\my_screenshot.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);

            //test for recycle bin
            ShellFileOperations.EmptyRecycleBin(IntPtr.Zero, null, ShellFileOperations.EmptyRecycleBinFlags.None); 

            return;
        }


    }
}
