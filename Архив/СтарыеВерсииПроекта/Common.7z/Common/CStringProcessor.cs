﻿using System;
using System.IO;
using System.Text;

namespace Common
{
    /// <summary>
    /// Различные функции текстовых строк
    /// </summary>
    public class CStringProcessor
    {
        /// <summary>
        /// RT-Конвертировать блок данных в строку
        /// </summary>
        /// <param name="bar">Конвертируемый блок данных</param>
        /// <returns></returns>
        public static string BytesToString(byte[] bar)
        {
            MemoryStream ms = new MemoryStream(bar);
            BinaryReader br = new BinaryReader(ms, Encoding.UTF8);

            String text = br.ReadString();
            br.Close();//close reader and stream
            return text;
        }

        /// <summary>
        /// RT-Конвертировать строку в блок данных
        /// </summary>
        /// <param name="text">Конвертируемая строка</param>
        /// <returns></returns>
        public static byte[] StringToBytes(string text)
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms, Encoding.UTF8);
            bw.Write(text);
            bw.Flush();
            byte[] res = ms.ToArray();
            bw.Close();//close writer and stream

            return res;
            //throw new NotImplementedException();
        }

    }
}
