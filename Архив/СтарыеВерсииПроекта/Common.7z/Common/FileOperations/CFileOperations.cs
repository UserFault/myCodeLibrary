﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Common.FileOperations
{
    /// <summary>
    /// Общие операции с файлами
    /// </summary>
    public class CFileOperations
    {
        /// <summary>
        /// Расширение файла-ярлыка
        /// </summary>
        public const string ShortcutFileExtension = ".lnk";

        /// <summary>
        /// NT-Проверить по расширению файла, что файл является ярлыком.
        /// </summary>
        /// <param name="notePath">Путь к файлу-ярлыку</param>
        /// <returns>True если это файл-ярлык</returns>
        public static bool IsShortcutFile(string notePath)
        {
            string ext = Path.GetExtension(notePath);
            return String.Equals(ext, ".lnk", StringComparison.OrdinalIgnoreCase);
        }
        /// <summary>
        /// Заменить неправильные символы пути файла в строке на указанный символ
        /// </summary>
        /// <param name="s">Строка пути файла</param>
        /// <param name="rChar">Символ на замену</param>
        /// <returns>Возвращает строку не содержащую неправильных символов имени файла</returns>
        public static string ReplaceInvalidFilenameChars(string s, char rChar)
        {
            //Получаем массив запрещенных символов
            char[] inv = Path.GetInvalidFileNameChars();
            //Создаем билдер для сборки символов
            StringBuilder sb = new StringBuilder();
            foreach (Char c in s)
            {
                //если символ есть в массиве, то вместо него пишем замену, иначе пишем сам символ
                if (Array.IndexOf(inv, c) == -1)
                    sb.Append(c);
                else sb.Append(rChar);
            }
            return sb.ToString();
        }


    }
}
